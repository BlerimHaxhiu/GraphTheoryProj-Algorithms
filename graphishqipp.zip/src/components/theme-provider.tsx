'use client';

import type { FC, ReactNode } from 'react';
import { useEffect } from 'react';

interface ThemeProviderProps {
  children: ReactNode;
}

export const ThemeProvider: FC<ThemeProviderProps> = ({ children }) => {
  useEffect(() => {
    // This ensures the 'dark' class is applied on the client side.
    // For a more complete solution, this could read from localStorage or system preferences.
    document.documentElement.classList.add('dark');
    // Optionally, ensure 'light' class is not present if it could be set by other means
    // document.documentElement.classList.remove('light'); 
  }, []);

  return <>{children}</>;
};
