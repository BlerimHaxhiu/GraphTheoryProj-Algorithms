'use client';

import type { AdjacencyMatrix, Node, AlgorithmStep } from '@/types/graph';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { ScrollArea } from '@/components/ui/scroll-area';
import { cn } from '@/lib/utils';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Grid3X3 } from 'lucide-react'; // Icon for matrix

interface AdjacencyMatrixTableProps {
  matrix: AdjacencyMatrix;
  nodes: Node[];
  currentAlgorithmStep: AlgorithmStep | null;
}

export function AdjacencyMatrixTable({ matrix, nodes, currentAlgorithmStep }: AdjacencyMatrixTableProps) {
  const getNodeIndex = (nodeId: string) => nodes.findIndex(n => n.id === nodeId);
  let highlightedCells: { row: number; col: number }[] = [];

  if (currentAlgorithmStep) {
    if (currentAlgorithmStep.type === 'visit-node' && currentAlgorithmStep.nodeId) {
      // Highlighting for visit-node can be too broad for matrix, consider if needed
    } else if (currentAlgorithmStep.type === 'traverse-edge' && currentAlgorithmStep.edgeId && currentAlgorithmStep.highlightSourceNodeId) {
        const sourceIdx = getNodeIndex(currentAlgorithmStep.highlightSourceNodeId);
        const targetIdx = getNodeIndex(currentAlgorithmStep.nodeId); 
        if (sourceIdx !== -1 && targetIdx !== -1) {
             highlightedCells.push({ row: sourceIdx, col: targetIdx });
        }
    } else if (currentAlgorithmStep.type === 'highlight-path' && currentAlgorithmStep.path) {
        for (let i = 0; i < currentAlgorithmStep.path.length - 1; i++) {
            const sourceIdx = getNodeIndex(currentAlgorithmStep.path[i]);
            const targetIdx = getNodeIndex(currentAlgorithmStep.path[i+1]);
            if (sourceIdx !== -1 && targetIdx !== -1) {
                highlightedCells.push({ row: sourceIdx, col: targetIdx });
            }
        }
    }
  }
  
  return (
    <Card className="flex flex-col shadow-md h-full overflow-hidden">
      <CardHeader className="py-3 px-4 border-b">
        <CardTitle className="text-md sm:text-lg flex items-center gap-2">
          <Grid3X3 className="h-5 w-5 text-primary" /> 
          Matrica e Fqinjësisë
        </CardTitle>
      </CardHeader>
      <CardContent className="flex-grow p-0 overflow-hidden"> {/* Ensure CardContent allows ScrollArea to define scrolling */}
        <ScrollArea className="h-full w-full"> {/* ScrollArea will handle the overflow */}
          {nodes.length === 0 ? (
             <div className="p-4 text-center text-muted-foreground h-full flex flex-col items-center justify-center">
               <Grid3X3 className="w-12 h-12 text-muted-foreground/30 mb-3" data-ai-hint="matrix icon" />
               <span className="text-sm">Matrica do të shfaqet këtu.</span>
               <span className="text-xs">Shtoni nyje në graf për ta populluar atë.</span>
             </div>
          ) : (
            <Table className="min-w-max border-collapse"> {/* min-w-max allows table to grow as needed, triggering ScrollArea */}
              <TableHeader className="sticky top-0 bg-card/95 z-10"> {/* Sticky header for vertical scroll */}
                <TableRow>
                  <TableHead className={cn(
                    "sticky left-0 bg-card/95 text-center z-20", 
                    "p-1 text-[10px] min-w-[28px] w-auto",      
                    "sm:text-xs sm:min-w-[32px] sm:p-1.5",  
                    "md:text-sm md:min-w-[36px] md:p-2"              
                  )}>
                    {/* Empty corner cell */}
                  </TableHead>
                  {nodes.map(node => (
                    <TableHead 
                      key={node.id} 
                      className={cn(
                        "text-center font-semibold whitespace-nowrap",
                        "p-1 text-[10px] min-w-[28px] w-auto",     
                        "sm:text-xs sm:min-w-[32px] sm:p-1.5", 
                        "md:text-sm md:min-w-[36px] md:p-2"              
                      )}
                    >
                      {node.label}
                    </TableHead>
                  ))}
                </TableRow>
              </TableHeader>
              <TableBody>
                {nodes.map((rowNode, rowIndex) => (
                  <TableRow key={rowNode.id}>
                    <TableHead // Using TableHead for sticky row headers for consistent styling
                      className={cn(
                        "sticky left-0 bg-card/95 text-center font-semibold whitespace-nowrap z-10",
                        "p-1 text-[10px] min-w-[28px] w-auto",      
                        "sm:text-xs sm:min-w-[32px] sm:p-1.5",  
                        "md:text-sm md:min-w-[36px] md:p-2"                 
                      )}
                    >
                      {rowNode.label}
                    </TableHead>
                    {nodes.map((colNode, colIndex) => {
                      const isHighlighted = highlightedCells.some(cell => cell.row === rowIndex && cell.col === colIndex);
                      const cellValue = matrix[rowIndex]?.[colIndex];                      
                      return (
                        <TableCell
                          key={colNode.id}
                          className={cn(                            
                            "text-center border",
                            "p-1 text-[10px] min-w-[28px] w-auto",      
                            "sm:text-xs sm:min-w-[32px] sm:p-1.5",  
                            "md:text-sm md:min-w-[36px] md:p-2",                
                            isHighlighted ? 'bg-accent/40 text-accent-foreground font-bold' : '',
                            cellValue === Infinity || cellValue === undefined ? 'text-muted-foreground' : ''
                          )}
                        >
                          {cellValue === Infinity || cellValue === undefined ? '∞' : cellValue}
                        </TableCell>
                      );
                    })}
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </ScrollArea>
      </CardContent>
    </Card>
  );
}
