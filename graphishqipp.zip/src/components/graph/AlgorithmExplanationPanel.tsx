
'use client';

import type { AlgorithmType } from '@/types/graph';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { BookOpenText, HelpCircle } from 'lucide-react';
import { cn } from '@/lib/utils';

interface AlgorithmExplanationPanelProps {
  algorithm: AlgorithmType | null;
}

const explanations: Record<AlgorithmType, { title: string; description: string; complexity?: string }> = {
  'bfs': {
    title: 'Kërkimi në Gjerësi (BFS)',
    description: 'Kërkimi në Gjerësi (BFS) është një algoritëm për kalimin ose kërkimin në strukturat e të dhënave të grafeve. Ai fillon nga një nyje burimore e zgjedhur dhe eksploron të gjithë fqinjët e saj në thellësinë aktuale para se të lëvizë te nyjet në nivelin tjetër të thellësisë.\n\nPër të mbajtur gjurmët e nyjeve fëmijë që u hasën por nuk u eksploruan ende, BFS përdor një strukturë të dhënash radhë (queue) (First-In-First-Out). Nyja burimore shtohet në radhë. Në çdo hap, algoritmi merr nyjen e parë nga radha, e viziton atë dhe shton fqinjët e saj të pa vizituar në fund të radhës.\n\nBFS është i garantuar të gjejë rrugën më të shkurtër në terma të numrit të brinjëve midis dy nyjeve në një graf pa pesha, sepse eksploron grafin shtresë pas shtrese.',
    complexity: 'O(V + E)'
  },
  'dfs': {
    title: 'Kërkimi në Thellësi (DFS)',
    description: 'Kërkimi në Thellësi (DFS) është një algoritëm për kalimin ose kërkimin në strukturat e të dhënave të grafeve. Algoritmi fillon nga një nyje burimore e zgjedhur dhe eksploron sa më larg që të jetë e mundur përgjatë çdo dege para se të kthehet prapa (backtracking).\n\nPër të mbajtur gjurmët e nyjeve që duhen vizituar, DFS përdor një strukturë të dhënash stack (Last-In-First-Out), qoftë në mënyrë eksplicite ose implicite përmes rekursionit. Kur arrin një nyje pa fqinjë të pa vizituar, ose kur të gjitha degët nga ajo nyje janë eksploruar plotësisht, algoritmi kthehet prapa te nyja e mëparshme për të eksploruar degë të tjera.\n\nDFS përdoret shpesh për zbulimin e cikleve në grafe, për renditje topologjike, për të gjetur komponentët e lidhur fort, dhe në zgjidhjen e problemeve si labirintet.',
    complexity: 'O(V + E)'
  },
  'dijkstra': {
    title: 'Algoritmi i Dijkstra-s',
    description: "Algoritmi i Dijkstra-s, i konceptuar nga Edsger W. Dijkstra në 1956, është një algoritëm lakmitar (greedy) që zgjidh problemin e rrugës më të shkurtër për një graf me pesha jo-negative në brinjë, nga një nyje e vetme burimore tek të gjitha nyjet e tjera në graf.\n\nAi funksionon duke mbajtur një bashkësi të nyjeve të vizituara dhe një bashkësi të distancave të përkohshme për çdo nyje. Fillimisht, të gjitha distancat vendosen në pafundësi, përveç nyjes burimore që ka distancë 0. Algoritmi në mënyrë të përsëritur zgjedh nyjen e pa vizituar me distancën më të vogël të përkohshme, e shënon si të vizituar dhe përditëson distancat e fqinjëve të saj. Për të zgjedhur në mënyrë efikase nyjen me distancën më të vogël, shpesh përdoret një strukturë të dhënash prioritare (priority queue).\n\nAlgoritmi përfundon kur të gjitha nyjet e arritshme janë vizituar, ose kur nyja destinacion (nëse është specifikuar) është vizituar.",
    complexity: 'O(E log V) ose O(V^2) varësisht nga implementimi'
  },
  'a-star': {
    title: 'Algoritmi A* (A-yll)',
    description: "Algoritmi A* (A-yll) është një algoritëm kërkimi i informuar dhe një nga algoritmet më të njohura për gjetjen e rrugës më të shkurtër nga një nyje fillestare tek një nyje përfundimtare në një graf. Ai kombinon tiparet e algoritmit të Dijkstra-s (që favorizon rrugët me kosto më të ulët të deritanishme) me një heuristikë për të udhëhequr kërkimin drejt nyjes cak.\n\nFormula kryesore që përdor A* për të vlerësuar çdo nyje (n) është:\nF(n) = G(n) + H(n)\nKu:\n- F(n) është kostoja totale e vlerësuar e rrugës më të lirë nga nyja fillestare tek caku, duke kaluar përmes nyjes n.\n- G(n) është kostoja aktuale e rrugës më të lirë të njohur nga nyja fillestare tek nyja n (e ngjashme me Dijkstra).\n- H(n) është një funksion heuristik që vlerëson koston e rrugës më të lirë nga nyja n tek nyja cak. Heuristika duhet të jetë e pranueshme (të mos mbivlerësojë koston reale) dhe konsistente për të garantuar që A* të gjejë rrugën më të shkurtër optimale.\n\nA* përdor një radhë prioritare për të eksploruar nyjet me vlerën më të ulët F(n) së pari. Nëse heuristika H(n) është 0, A* sillet si Dijkstra. Nëse H(n) është një vlerësim i mirë, A* mund të gjejë rrugën më të shkurtër shumë më shpejt se Dijkstra duke eksploruar më pak nyje.",
    complexity: 'Varion, por mund të jetë O(E log V) në raste të mira me heuristikë të mirë'
  },
  'bellman-ford': {
    title: 'Algoritmi i Bellman-Ford-it',
    description: "Algoritmi i Bellman-Ford-it është një algoritëm që llogarit rrugët më të shkurtra nga një nyje e vetme burimore tek të gjitha nyjet e tjera në një graf me pesha. Ndryshe nga algoritmi i Dijkstra-s, Bellman-Ford mund të përdoret edhe në grafe që përmbajnë brinjë me pesha negative.\n\nAlgoritmi funksionon duke relaksuar në mënyrë të përsëritur të gjitha brinjët e grafikut. Në secilin nga |V|-1 iteracionet (ku |V| është numri i nyjeve), ai kalon përmes të gjitha brinjëve dhe përditëson distancën deri te nyja destinacion e brinjës nëse gjendet një rrugë më e shkurtër përmes nyjes burimore të asaj brinje.\n\nPas |V|-1 iteracionesh, nëse nuk ka cikle me peshë negative, distancat e llogaritura janë rrugët më të shkurtra. Një iteracion i |V|-të kryhet për të zbuluar praninë e cikleve me peshë negative. Nëse ndonjë distancë mund të përditësohet ende në këtë iteracion, atëherë ekziston një cikël me peshë negative i arritshëm nga nyja burimore, dhe rrugët më të shkurtra për disa nyje mund të jenë të papërcaktuara (pafundësisht të vogla).",
    complexity: 'O(V * E)'
  },
  'floyd-warshall': {
    title: 'Algoritmi i Floyd-Warshall-it',
    description: "Algoritmi i Floyd-Warshall-it është një algoritëm programimi dinamik për gjetjen e rrugëve më të shkurtra midis të gjitha çifteve të nyjeve në një graf të drejtuar me pesha (mund të ketë pesha negative, por jo cikle me peshë negative).\n\nAi funksionon duke konsideruar në mënyrë iteracionale të gjitha nyjet si nyje të ndërmjetme të mundshme në rrugët më të shkurtra. Për çdo çift nyjesh (i, j), algoritmi kontrollon nëse rruga nga i te j mund të përmirësohet duke kaluar përmes një nyje të ndërmjetme k. Kjo do të thotë, ai krahason distancën aktuale dist(i, j) me dist(i, k) + dist(k, j) dhe përditëson dist(i, j) nëse kjo e fundit është më e vogël.\n\nProcesi përsëritet për të gjitha nyjet k si nyje të ndërmjetme. Pas përfundimit të të gjitha iteracioneve, matrica e distancave përmban rrugët më të shkurtra midis të gjitha çifteve të nyjeve. Nëse ka një vlerë negative në diagonalen kryesore të matricës së distancave pas përfundimit, kjo tregon praninë e një cikli me peshë negative.",
    complexity: 'O(V³)'
  },
  'kruskal': {
    title: 'Algoritmi i Kruskal-it (MST)',
    description: "Algoritmi i Kruskal-it është një algoritëm lakmitar (greedy) që gjen një Pemë Minimale Mbuluese (Minimum Spanning Tree - MST) për një graf të lidhur, pa drejtim dhe me pesha. Një MST është një nëngraf që lidh të gjitha nyjet e grafikut pa asnjë cikël dhe me peshën totale minimale të mundshme të brinjëve.\n\nAlgoritmi funksionon në këtë mënyrë:\n1. Krijon një pyll F (një bashkësi pemësh), ku çdo nyje në graf është një pemë e veçantë.\n2. Krijon një bashkësi S që përmban të gjitha brinjët në graf.\n3. Për sa kohë që S nuk është boshe dhe F nuk është ende një pemë mbuluese (zakonisht kur ka më pak se |V|-1 brinjë):\n    a. Hiq një brinjë me peshën minimale nga S.\n    b. Nëse brinja e hequr lidh dy pemë të ndryshme në F, atëherë shtoje atë në F, duke kombinuar dy pemët në një pemë të vetme.\n    c. Përndryshe (nëse brinja lidh dy nyje që tashmë janë në të njëjtën pemë, pra formon një cikël), hidhe poshtë brinjën.\n\nPër të kontrolluar nëse dy nyje janë në të njëjtën pemë (d.m.th., për të zbuluar ciklet), zakonisht përdoret një strukturë e të dhënave Disjoint Set Union (DSU).",
    complexity: 'O(E log E) ose O(E log V)'
  },
  'prim': {
    title: 'Algoritmi i Prim-it (MST)',
    description: "Algoritmi i Prim-it është një tjetër algoritëm lakmitar (greedy) që gjen një Pemë Minimale Mbuluese (MST) për një graf të lidhur, pa drejtim dhe me pesha. Ai funksionon duke ndërtuar pemën hap pas hapi, duke filluar nga një nyje arbitrare.\n\nProcesi është si më poshtë:\n1. Inicializo një pemë me një nyje të vetme, të zgjedhur arbitrarisht nga grafi.\n2. Për sa kohë që ka nyje që nuk janë ende në pemë:\n    a. Zgjidh brinjën me peshën më të vogël që lidh një nyje në pemë me një nyje jashtë pemës (prerja).\n    b. Shto këtë brinjë dhe nyjen e re në pemë.\n\nPër të implementuar këtë në mënyrë efikase, zakonisht përdoret një radhë prioritare (priority queue) për të ruajtur brinjët që dalin nga pema e ndërtuar deri më tani, të renditura sipas peshës së tyre. Kjo lejon zgjedhjen e shpejtë të brinjës me peshë minimale në çdo hap.\n\nAlgoritmi i Prim-it është shumë i ngjashëm me algoritmin e Dijkstra-s. Dallimi kryesor është se si ato zgjedhin 'distancën' e një nyje: Dijkstra përdor distancën nga burimi, ndërsa Prim përdor peshën e brinjës lidhëse me pemën e pjesshme.",
    complexity: 'O(E log V) ose O(V^2) varësisht nga implementimi'
  }
};

export function AlgorithmExplanationPanel({ algorithm }: AlgorithmExplanationPanelProps) {
  const content = algorithm ? explanations[algorithm] : null;

  return (
    <Card className="shadow-lg h-full flex flex-col">
      <CardHeader className="pb-2 pt-4 px-4">
        <CardTitle className="text-lg flex items-center">
          <BookOpenText className="h-5 w-5 mr-2 text-primary" />
          Si Vepron Algoritmi?
        </CardTitle>
      </CardHeader>
      <CardContent className="px-0 py-0 flex-grow overflow-hidden">
        <ScrollArea className="h-full w-full p-4">
          {content ? (
            <div className="space-y-3 text-sm">
              <h3 className="font-semibold text-md text-primary">{content.title}</h3>
              <p className="text-muted-foreground leading-relaxed whitespace-pre-line">{content.description}</p>
              {content.complexity && (
                <p className="text-xs text-muted-foreground/80 pt-2">
                  <span className="font-semibold text-muted-foreground">Kompleksiteti Kohor Tipik:</span> {content.complexity}
                </p>
              )}
            </div>
          ) : (
            <div className="text-center text-muted-foreground h-full flex flex-col items-center justify-center p-4">
              <HelpCircle className="w-10 h-10 text-muted-foreground/30 mb-3" />
              <p className="text-sm">Zgjidhni dhe ekzekutoni një algoritëm për të parë shpjegimin e tij teorik këtu.</p>
            </div>
          )}
        </ScrollArea>
      </CardContent>
    </Card>
  );
}

