
'use client';

import type { ExecutionLogEntry, Node, Edge, AlgorithmType } from '@/types/graph';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { GitCompareArrows, Clock, Route, ListTree, Variable } from 'lucide-react'; // Added Variable for V, E
import { format } from 'date-fns';
import { sq } from 'date-fns/locale'; // Albanian locale for date-fns
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { cn } from '@/lib/utils';

interface CompareAlgorithmsPanelProps {
  history: ExecutionLogEntry[];
  nodes: Node[]; // Current nodes, for context if needed, but snapshots are primary
  edges: Edge[]; // Current edges
  isDirected: boolean; // Current graph direction
}

const ALGORITHM_COMPLEXITIES: Record<AlgorithmType, string> = {
  'bfs': 'O(V + E)',
  'dfs': 'O(V + E)',
  'dijkstra': 'O(E log V)', // Simplified, common case with Priority Queue
  'a-star': 'O(E log V)', // Similar to Dijkstra with heuristic
  'bellman-ford': 'O(V * E)',
  'floyd-warshall': 'O(V³)',
  'kruskal': 'O(E log E)',
  'prim': 'O(E log V)', // Simplified, common case with Priority Queue
};

export function CompareAlgorithmsPanel({ history, nodes, edges, isDirected }: CompareAlgorithmsPanelProps) {
  return (
    <Card className="shadow-lg h-[400px] flex flex-col"> {/* Increased height for more content */}
      <CardHeader className="pb-2 pt-4 px-4">
        <CardTitle className="text-lg flex items-center">
          <GitCompareArrows className="h-5 w-5 mr-2 text-primary" />
          Krahaso Algoritmet
        </CardTitle>
      </CardHeader>
      <CardContent className="px-0 py-2 flex-grow overflow-hidden">
        {history.length === 0 ? (
          <p className="text-sm text-muted-foreground text-center py-4 px-4 h-full flex items-center justify-center">
            Ekzekutoni disa algoritme për të parë krahasimin e tyre këtu.
          </p>
        ) : (
          <ScrollArea className="h-full w-full">
            <Table className="text-xs">
              <TableHeader className="sticky top-0 bg-card/95 z-10">
                <TableRow>
                  <TableHead className="px-2 py-1.5 sm:px-3 sm:py-2">Algoritmi</TableHead>
                  <TableHead className="px-2 py-1.5 sm:px-3 sm:py-2 text-center">Koha (ms)</TableHead>
                  <TableHead className="px-2 py-1.5 sm:px-3 sm:py-2">Kompleksiteti</TableHead>
                  <TableHead className="px-2 py-1.5 sm:px-3 sm:py-2 text-center">V | E</TableHead>
                  <TableHead className="px-2 py-1.5 sm:px-3 sm:py-2">Përmbledhje</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {history.slice().reverse().map((entry) => (
                  <TableRow key={entry.id} className="hover:bg-muted/20">
                    <TableCell className="px-2 py-1.5 sm:px-3 sm:py-2 font-medium text-primary truncate max-w-[100px] sm:max-w-[120px]">
                      {entry.algorithm.toUpperCase()}
                      <div className="text-muted-foreground text-[10px] sm:text-[11px]">
                        {format(entry.startTime, "HH:mm:ss", { locale: sq })}
                      </div>
                    </TableCell>
                    <TableCell className="px-2 py-1.5 sm:px-3 sm:py-2 text-center tabular-nums">
                      {entry.executionTimeMs.toFixed(2)}
                    </TableCell>
                    <TableCell className="px-2 py-1.5 sm:px-3 sm:py-2 text-muted-foreground">
                      {ALGORITHM_COMPLEXITIES[entry.algorithm] || 'N/A'}
                    </TableCell>
                    <TableCell className="px-2 py-1.5 sm:px-3 sm:py-2 text-center text-muted-foreground tabular-nums">
                      {entry.nodesCountSnapshot} | {entry.edgesCountSnapshot}
                    </TableCell>
                    <TableCell className="px-2 py-1.5 sm:px-3 sm:py-2 text-muted-foreground italic whitespace-normal">
                      {entry.resultSummary}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </ScrollArea>
        )}
      </CardContent>
    </Card>
  );
}

