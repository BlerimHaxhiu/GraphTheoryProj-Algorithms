
// @ts-nocheck
'use client';

import React, { useState, useRef, useEffect, useCallback } from 'react';
import type { Node, Edge, AlgorithmStep, SelectedToolType, EdgeDrawType } from '@/types/graph';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Label } from '@/components/ui/label';
import { cn } from '@/lib/utils';
import { X, GitFork, DraftingCompass, Edit3, RotateCcw, Shapes, PencilRuler, WandSparkles } from 'lucide-react';

interface GraphCanvasProps {
  svgRef: React.RefObject<SVGSVGElement>;
  nodes: Node[];
  edges: Edge[];
  isDirected: boolean;
  onNodesChange: (nodes: Node[]) => void;
  onEdgesChange: (edges: Edge[]) => void;
  selectedTool: SelectedToolType;
  setSelectedTool: (tool: SelectedToolType) => void;
  currentAlgorithmStep: AlgorithmStep | null;
  startNode: string | null;
  endNode: string | null;
  setStartNode: (nodeId: string | null) => void;
  setEndNode: (nodeId: string | null) => void;
  onDeleteNode: (nodeId: string) => void;
  onAddNode: (x?: number, y?: number) => void;
  edgeDrawType: EdgeDrawType;
}

const NODE_RADIUS = 20;
const CANVAS_PADDING = 20;

const getClientCoords = (event: any): {clientX: number, clientY: number} | null => {
  if (event.touches && event.touches.length > 0) {
    return { clientX: event.touches[0].clientX, clientY: event.touches[0].clientY };
  }
  if (event.nativeEvent && event.nativeEvent.touches && event.nativeEvent.touches.length > 0) {
    return { clientX: event.nativeEvent.touches[0].clientX, clientY: event.nativeEvent.touches[0].clientY };
  }
  if (event.clientX !== undefined && event.clientY !== undefined) {
    return { clientX: event.clientX, clientY: event.clientY };
  }
  if (event.nativeEvent && event.nativeEvent.clientX !== undefined && event.nativeEvent.clientY !== undefined) {
    return { clientX: event.nativeEvent.clientX, clientY: event.nativeEvent.clientY };
  }
  return null;
};


export function GraphCanvas({
  svgRef,
  nodes,
  edges,
  isDirected,
  onNodesChange,
  onEdgesChange,
  selectedTool,
  setSelectedTool,
  currentAlgorithmStep,
  startNode,
  endNode,
  setStartNode,
  setEndNode,
  onDeleteNode,
  onAddNode,
  edgeDrawType,
}: GraphCanvasProps) {
  const [viewBox, setViewBox] = useState('0 0 800 600');
  const [isDraggingNode, setIsDraggingNode] = useState<string | null>(null);
  const [dragOffset, setDragOffset] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [isPanning, setIsPanning] = useState(false);
  const [panStart, setPanStart] = useState<{ x: number; y: number }>({ x: 0, y: 0 });

  const [edgeCreationSource, setEdgeCreationSource] = useState<string | null>(null);
  const [edgeWeightPopoverOpen, setEdgeWeightPopoverOpen] = useState(false);
  const [currentEdgeCandidate, setCurrentEdgeCandidate] = useState<{ source: string; target: string } | null>(null);
  const [edgeWeight, setEdgeWeight] = useState<number>(1);
  const [edgeToEditId, setEdgeToEditId] = useState<string | null>(null);

  const [popoverPosition, setPopoverPosition] = useState<{ x: number; y: number }>({ x: 0, y: 0 });


  const getSVGCoordinates = useCallback((event: React.MouseEvent | MouseEvent | React.TouchEvent | TouchEvent): { x: number; y: number } => {
    if (!svgRef.current) return { x: 0, y: 0 };

    const clientCoords = getClientCoords(event);
    if (!clientCoords) {
        console.warn("Could not get client coordinates from event");
        return { x: 0, y: 0 };
    }

    const pt = svgRef.current.createSVGPoint();
    pt.x = clientCoords.clientX;
    pt.y = clientCoords.clientY;

    const ctm = svgRef.current.getScreenCTM();
    if (ctm) {
        return pt.matrixTransform(ctm.inverse());
    }
    console.warn("Could not get CTM from SVG");
    return { x: 0, y: 0 };
  }, [svgRef]);


  const handleMouseDownSVG = (event: React.MouseEvent<SVGSVGElement>) => {
    if (selectedTool === 'pointer' && event.target === svgRef.current) {
      setIsPanning(true);
      const coords = getSVGCoordinates(event);
      setPanStart(coords);
    }
  };

  const handleMouseMoveSVG = (event: React.MouseEvent<SVGSVGElement>) => {
    if (isPanning && svgRef.current) {
      const coords = getSVGCoordinates(event);
      const dx = coords.x - panStart.x;
      const dy = coords.y - panStart.y;
      const [vx, vy, vw, vh] = viewBox.split(' ').map(Number);
      setViewBox(`${vx - dx} ${vy - dy} ${vw} ${vh}`);
    }
  };

  const handleMouseUpSVG = () => {
    setIsPanning(false);
  };

  const handleMouseLeaveSVG = () => {
    setIsPanning(false);
    if (isDraggingNode) {
        setIsDraggingNode(null);
    }
  };

  const handleCanvasClick = (event: React.MouseEvent<SVGSVGElement>) => {
    if (event.target === svgRef.current) { // Click on canvas background
      const coords = getSVGCoordinates(event);
      onAddNode(coords.x, coords.y);
    } else if (selectedTool === 'add-edge') {
      if (edgeCreationSource && event.target === svgRef.current) {
        setEdgeCreationSource(null);
      }
    }
     setEdgeToEditId(null);
  };

  const handleNodeMouseDown = (event: React.MouseEvent | React.TouchEvent, nodeId: string) => {
    event.stopPropagation();
    if (selectedTool === 'pointer') {
      setIsDraggingNode(nodeId);
      const node = nodes.find(n => n.id === nodeId);
      const coords = getSVGCoordinates(event);
      if (node) {
        setDragOffset({ x: coords.x - node.x, y: coords.y - node.y });
      }
    }
  };

  const handleNodeMouseUp = (event: React.MouseEvent | React.TouchEvent, nodeId: string) => {
    event.stopPropagation();
    setIsDraggingNode(null);
  };

  const handleNodeClick = (event: React.MouseEvent, nodeId: string) => {
    event.stopPropagation();
    setEdgeToEditId(null);

    const clientCoords = getClientCoords(event);
    if (clientCoords) {
      setPopoverPosition({ x: clientCoords.clientX, y: clientCoords.clientY });
    }

    if (selectedTool === 'add-edge') {
      if (!edgeCreationSource) {
        setEdgeCreationSource(nodeId);
      } else if (edgeCreationSource === nodeId) { // Self-loop attempt
        setCurrentEdgeCandidate({ source: edgeCreationSource, target: nodeId });
        setEdgeWeight(1);
        setEdgeWeightPopoverOpen(true);
      } else if (edgeCreationSource !== nodeId) {
        setCurrentEdgeCandidate({ source: edgeCreationSource, target: nodeId });
        setEdgeWeight(1);
        setEdgeWeightPopoverOpen(true);
      }
    } else if (selectedTool === 'pointer') {
      if (!startNode || (startNode && endNode)) {
        setStartNode(nodeId);
        setEndNode(null);
      } else if (startNode && !endNode && startNode !== nodeId) {
        setEndNode(nodeId);
      } else if (startNode === nodeId) {
        if (endNode) {
           setStartNode(null);
           setEndNode(null);
        } else {
            setStartNode(null);
        }
      } else if (endNode === nodeId) {
         setEndNode(null);
      }
    }
  };

  const handleNodeContextMenu = (event: React.MouseEvent, nodeId: string) => {
    event.preventDefault();
    onDeleteNode(nodeId);
    setSelectedTool('pointer');
    setEdgeCreationSource(null);
    setEdgeToEditId(null);
    setEdgeWeightPopoverOpen(false);
  };

  const handleEdgeWeightClick = (event: React.MouseEvent, edge: Edge) => {
    event.stopPropagation();
    if (selectedTool !== 'pointer' && selectedTool !== 'add-edge') {
        setSelectedTool('pointer');
    }
    const clientCoords = getClientCoords(event);
    if (clientCoords) {
      setPopoverPosition({ x: clientCoords.clientX, y: clientCoords.clientY });
    }
    setEdgeToEditId(edge.id);
    setEdgeWeight(edge.weight);
    setCurrentEdgeCandidate(null);
    setEdgeCreationSource(null);
    setEdgeWeightPopoverOpen(true);
  };

  const handleAddEdgeWithWeight = () => {
    if (edgeToEditId) {
        const updatedEdges = edges.map(e =>
            e.id === edgeToEditId ? { ...e, weight: Number(edgeWeight) || 0 } : e
        );
        onEdgesChange(updatedEdges);
    } else if (currentEdgeCandidate) {
      const newEdge = {
        id: `edge-${currentEdgeCandidate.source}-${currentEdgeCandidate.target}-${Math.random().toString(16).slice(2)}`,
        source: currentEdgeCandidate.source,
        target: currentEdgeCandidate.target,
        weight: Number(edgeWeight) || 0
      };

      const isLoop = newEdge.source === newEdge.target;
      let allowNewEdge = true;

      if (isLoop) {
        const existingLoop = edges.find(e => e.source === newEdge.source && e.target === newEdge.target);
        if (existingLoop && isDirected) {
        } else if (existingLoop) {
            allowNewEdge = false;
        }

      } else if (!isDirected) {
        const existingNonLoopDuplicate = edges.find(e =>
          (e.source === newEdge.source && e.target === newEdge.target) ||
          (e.source === newEdge.target && e.target === newEdge.source)
        );
        if (existingNonLoopDuplicate) allowNewEdge = false;
      } else {
         const existingExactDuplicate = edges.find(e =>
            e.source === newEdge.source && e.target === newEdge.target
         );
         if(existingExactDuplicate) allowNewEdge = false;
      }

      if (allowNewEdge) {
        onEdgesChange([...edges, newEdge]);
      }
    }

    setEdgeCreationSource(null);
    setCurrentEdgeCandidate(null);
    setEdgeToEditId(null);
    setEdgeWeightPopoverOpen(false);
    setEdgeWeight(1);
  };

  useEffect(() => {
    const handleGlobalMouseMove = (event: MouseEvent | TouchEvent) => {
      if (isDraggingNode && selectedTool === 'pointer' && svgRef.current) {
          const coords = getSVGCoordinates(event);
          if (!coords) return;

            const vb = svgRef.current.viewBox.baseVal;
            const canvasWidth = vb.width;
            const canvasHeight = vb.height;

            let newX = coords.x - dragOffset.x;
            let newY = coords.y - dragOffset.y;

            newX = Math.max(NODE_RADIUS + CANVAS_PADDING, Math.min(newX, canvasWidth - NODE_RADIUS - CANVAS_PADDING));
            newY = Math.max(NODE_RADIUS + CANVAS_PADDING, Math.min(newY, canvasHeight - NODE_RADIUS - CANVAS_PADDING));

            onNodesChange(
                nodes.map(n =>
                n.id === isDraggingNode ? { ...n, x: newX, y: newY } : n
                )
            );
      } else if (isPanning && svgRef.current) {
          const coords = getSVGCoordinates(event);
          if (!coords) return;
          const dx = coords.x - panStart.x;
          const dy = coords.y - panStart.y;
          const [vx, vy, vw, vh] = viewBox.split(' ').map(Number);
          setViewBox(`${vx - dx} ${vy - dy} ${vw} ${vh}`);
      }
    };
    const handleGlobalMouseUp = () => {
      if (isDraggingNode) setIsDraggingNode(null);
      if (isPanning) setIsPanning(false);
    };

    window.addEventListener('mousemove', handleGlobalMouseMove as EventListener);
    window.addEventListener('mouseup', handleGlobalMouseUp);
    window.addEventListener('touchmove', handleGlobalMouseMove as EventListener, { passive: false });
    window.addEventListener('touchend', handleGlobalMouseUp);

    return () => {
      window.removeEventListener('mousemove', handleGlobalMouseMove as EventListener);
      window.removeEventListener('mouseup', handleGlobalMouseUp);
      window.removeEventListener('touchmove', handleGlobalMouseMove as EventListener);
      window.removeEventListener('touchend', handleGlobalMouseUp);
    };
  }, [nodes, isDraggingNode, dragOffset, onNodesChange, selectedTool, isPanning, panStart, viewBox, getSVGCoordinates, svgRef]);


 const getEdgePath = (sourceNode: Node, targetNode: Node, edgeId: string, currentEdgeDrawType: EdgeDrawType) => {
    const x1_center = sourceNode.x;
    const y1_center = sourceNode.y;
    const x2_center = targetNode.x;
    const y2_center = targetNode.y;

    if (sourceNode.id === targetNode.id) { // Self-loop: Always curved
        const loopRadiusOffset = NODE_RADIUS * 0.8;
        const controlPointScale = 2.5;

        const angleOffset = 0.4; 
        const pathStartX = x1_center + NODE_RADIUS * Math.cos(-Math.PI / 2 - angleOffset);
        const pathStartY = y1_center + NODE_RADIUS * Math.sin(-Math.PI / 2 - angleOffset);

        const pathEndX = x1_center + NODE_RADIUS * Math.cos(-Math.PI / 2 + angleOffset) ;
        const pathEndY = y1_center + NODE_RADIUS * Math.sin(-Math.PI /2 + angleOffset) ;
        
        const control1X = x1_center + NODE_RADIUS * controlPointScale * 1.2; 
        const control1Y = y1_center - NODE_RADIUS * (controlPointScale + 1.5);
        const control2X = x1_center - NODE_RADIUS * controlPointScale * 1.2;
        const control2Y = y1_center - NODE_RADIUS * (controlPointScale + 1.5);


        return `M ${pathStartX},${pathStartY} C ${control1X},${control1Y} ${control2X},${control2Y} ${pathEndX},${pathEndY}`;
    }

    const dx_center = x2_center - x1_center;
    const dy_center = y2_center - y1_center;
    const dist_center = Math.sqrt(dx_center * dx_center + dy_center * dy_center);

    if (dist_center === 0) return ""; 

    let sx, sy, tx, ty;

    if (currentEdgeDrawType === 'curved') {
        const controlPointOffsetFactor = 0.25; 
        const midX_center = (x1_center + x2_center) / 2;
        const midY_center = (y1_center + y2_center) / 2;
        
        const perpDx = -dy_center / dist_center; 
        const perpDy = dx_center / dist_center;
        
        const curveOffsetMagnitude = dist_center * controlPointOffsetFactor;
        const controlX = midX_center + curveOffsetMagnitude * perpDx;
        const controlY = midY_center + curveOffsetMagnitude * perpDy;

        let tanSx = controlX - x1_center;
        let tanSy = controlY - y1_center;
        let lenTanS = Math.sqrt(tanSx*tanSx + tanSy*tanSy);
        if (lenTanS === 0) { 
            tanSx = dx_center; tanSy = dy_center; lenTanS = dist_center; 
        } 
        sx = x1_center + (tanSx / lenTanS) * NODE_RADIUS;
        sy = y1_center + (tanSy / lenTanS) * NODE_RADIUS;

        let tanTx = controlX - x2_center;
        let tanTy = controlY - y2_center;
        let lenTanT = Math.sqrt(tanTx*tanTx + tanTy*tanTy);
        if (lenTanT === 0) { 
            tanTx = -dx_center; tanTy = -dy_center; lenTanT = dist_center; 
        }
        tx = x2_center + (tanTx / lenTanT) * NODE_RADIUS;
        ty = y2_center + (tanTy / lenTanT) * NODE_RADIUS;
        
        return `M ${sx},${sy} Q ${controlX},${controlY} ${tx},${ty}`;

    } else { // Straight edge
        sx = x1_center + (dx_center * NODE_RADIUS) / dist_center;
        sy = y1_center + (dy_center * NODE_RADIUS) / dist_center;
        tx = x2_center - (dx_center * NODE_RADIUS) / dist_center;
        ty = y2_center - (dy_center * NODE_RADIUS) / dist_center;
        return `M ${sx},${sy} L ${tx},${ty}`;
    }
  };


  let highlightedNodes = new Set<string>();
  let highlightedEdges = new Set<string>();
  let currentPathNodes = new Set<string>();
  let currentPathEdges = new Set<string>();

  if (currentAlgorithmStep) {
    if (currentAlgorithmStep.type === 'visit-node' && currentAlgorithmStep.nodeId) {
      highlightedNodes.add(currentAlgorithmStep.nodeId);
    }
    if (currentAlgorithmStep.type === 'traverse-edge' && currentAlgorithmStep.edgeId) {
      highlightedEdges.add(currentAlgorithmStep.edgeId);
      const edge = edges.find(e => e.id === currentAlgorithmStep.edgeId);
      if (edge) {
        highlightedNodes.add(edge.target);
        if(currentAlgorithmStep.highlightSourceNodeId) {
             highlightedNodes.add(currentAlgorithmStep.highlightSourceNodeId);
        }
      }
    }
    if (currentAlgorithmStep.type === 'highlight-path' && currentAlgorithmStep.path) {
      currentAlgorithmStep.path.forEach(nodeId => currentPathNodes.add(nodeId));
      for (let i = 0; i < currentAlgorithmStep.path.length - 1; i++) {
        const sourceId = currentAlgorithmStep.path[i];
        const targetId = currentAlgorithmStep.path[i+1];
        const edge = edges.find(e =>
          (e.source === sourceId && e.target === targetId) ||
          (!isDirected && e.source === targetId && e.target === sourceId) ||
          (e.source === sourceId && e.target === sourceId && sourceId === targetId) // Self-loop check
        );
        if (edge) currentPathEdges.add(edge.id);
      }
    }
  }

  const nodeMap = new Map(nodes.map(n => [n.id, n]));


  return (
    <div className="relative w-full h-full bg-card rounded-lg shadow-inner overflow-hidden border border-border touch-none">
      <svg
        ref={svgRef}
        className={cn(
            "w-full h-full",
            selectedTool === 'pointer' && (isPanning ? 'cursor-grabbing' : (isDraggingNode ? 'cursor-grabbing' : 'cursor-grab')),
            (selectedTool === 'pointer' && !isDraggingNode && !isPanning) && 'cursor-copy', 
            selectedTool === 'add-edge' && (edgeCreationSource ? 'cursor-crosshair' : 'cursor-default')
        )}
        viewBox={viewBox}
        onMouseDown={handleMouseDownSVG}
        onMouseMove={handleMouseMoveSVG}
        onMouseUp={handleMouseUpSVG}
        onMouseLeave={handleMouseLeaveSVG}
        onClick={handleCanvasClick}
        onTouchStart={(e) => {
            if (selectedTool === 'pointer' && e.target === svgRef.current) {
                setIsPanning(true);
                const coords = getSVGCoordinates(e);
                 if (!coords) return;
                setPanStart(coords);
            }
        }}
        onTouchMove={(e) => {
             if (isPanning && svgRef.current) {
                e.preventDefault();
                const coords = getSVGCoordinates(e);
                 if (!coords) return;
                const dx = coords.x - panStart.x;
                const dy = coords.y - panStart.y;
                const [vx, vy, vw, vh] = viewBox.split(' ').map(Number);
                setViewBox(`${vx - dx} ${vy - dy} ${vw} ${vh}`);
            }
        }}
        onTouchEnd={() => setIsPanning(false)}

      >
        <defs>
          <marker
            id="arrowhead"
            viewBox="0 0 10 10"
            refX="9.5" 
            refY="5"
            markerWidth="6"
            markerHeight="6"
            orient="auto-start-reverse"
            fill="hsl(var(--foreground))" 
            fillOpacity="0.7"
          >
            <path d="M 0 0 L 10 5 L 0 10 z" />
          </marker>
          <marker
            id="arrowhead-highlight"
            viewBox="0 0 10 10"
            refX="9.5"
            refY="5"
            markerWidth="7"
            markerHeight="7"
            orient="auto-start-reverse"
            fill="hsl(var(--accent))" 
          >
            <path d="M 0 0 L 10 5 L 0 10 z" />
          </marker>
          <marker
            id="arrowhead-primary"
            viewBox="0 0 10 10"
            refX="9.5"
            refY="5"
            markerWidth="7"
            markerHeight="7"
            orient="auto-start-reverse"
            fill="hsl(var(--primary))" 
          >
            <path d="M 0 0 L 10 5 L 0 10 z" />
          </marker>
          <marker
            id="arrowhead-selfloop" 
            viewBox="0 0 10 10"
            refX="9.5" 
            refY="5"
            markerWidth="6"
            markerHeight="6"
            orient="auto" 
            fill="hsl(var(--foreground))" 
            fillOpacity="0.7"
          >
            <path d="M 0 0 L 10 5 L 0 10 z" />
          </marker>
            <marker
            id="arrowhead-selfloop-highlight"
            viewBox="0 0 10 10"
            refX="9.5"
            refY="5"
            markerWidth="7"
            markerHeight="7"
            orient="auto"
            fill="hsl(var(--accent))" 
          >
            <path d="M 0 0 L 10 5 L 0 10 z" />
          </marker>
           <marker
            id="arrowhead-selfloop-primary"
            viewBox="0 0 10 10"
            refX="9.5"
            refY="5"
            markerWidth="7"
            markerHeight="7"
            orient="auto"
            fill="hsl(var(--primary))" 
          >
            <path d="M 0 0 L 10 5 L 0 10 z" />
          </marker>
        </defs>

        {/* Edges */}
        {edges.map(edge => {
          const sourceNode = nodeMap.get(edge.source);
          const targetNode = nodeMap.get(edge.target);
          if (!sourceNode || !targetNode) return null;

          const isSelfLoop = sourceNode.id === targetNode.id;
          const path = getEdgePath(sourceNode, targetNode, edge.id, edgeDrawType);
          let midX, midY, textOffsetX = 0, textOffsetY = -8;
          
          let edgeTextFill = 'hsl(var(--foreground))'; 


           if (isSelfLoop) {
             midX = sourceNode.x; 
             midY = sourceNode.y - NODE_RADIUS * 2.8; 
             textOffsetY = -6;
          } else if (edgeDrawType === 'curved') {
             const qControlX = (sourceNode.x + targetNode.x) / 2 - (targetNode.y - sourceNode.y) * 0.25;
             const qControlY = (sourceNode.y + targetNode.y) / 2 + (targetNode.x - sourceNode.x) * 0.25;
             midX = 0.25*sourceNode.x + 0.5*qControlX + 0.25*targetNode.x; 
             midY = 0.25*sourceNode.y + 0.5*qControlY + 0.25*targetNode.y;

            const dx = targetNode.x - sourceNode.x;
            const dy = targetNode.y - sourceNode.y;
            const dist = Math.sqrt(dx*dx + dy*dy);
            if (dist > 0) {
                textOffsetX = (-dy / dist) * 10; 
                textOffsetY = (dx / dist) * 10 - 5; 
            } else {
                textOffsetY = -12; 
            }
          } else { 
             midX = (sourceNode.x + targetNode.x) / 2;
             midY = (sourceNode.y + targetNode.y) / 2;
          }


          const isHighlighted = highlightedEdges.has(edge.id);
          const isCurrentPath = currentPathEdges.has(edge.id);
          const isEditingThisEdge = edge.id === edgeToEditId;


          let stroke = 'hsl(var(--muted-foreground))'; 
          let arrowMarkerId = isSelfLoop ? "arrowhead-selfloop" : "arrowhead";


          if (isCurrentPath) {
            stroke = 'hsl(var(--accent))';
            arrowMarkerId = isSelfLoop ? "arrowhead-selfloop-highlight" : "arrowhead-highlight";
            edgeTextFill = 'hsl(var(--accent))'; 
          } else if (isHighlighted) {
            stroke = 'hsl(var(--primary))';
            arrowMarkerId = isSelfLoop ? "arrowhead-selfloop-primary" : "arrowhead-primary";
            edgeTextFill = 'hsl(var(--primary))';
          } else if (isEditingThisEdge) {
            stroke = 'hsl(var(--ring))';
            edgeTextFill = 'hsl(var(--ring))';
          }


          const strokeWidth = isCurrentPath || isHighlighted || isEditingThisEdge ? 2.5 : 1.5;

          return (
            <g key={edge.id} className="group/edge cursor-default">
              <path
                d={path}
                stroke={stroke}
                strokeWidth={strokeWidth}
                fill="none"
                markerEnd={isDirected ? `url(#${arrowMarkerId})` : undefined}
                className={cn(isEditingThisEdge && "animate-pulse")}
              />
              {edge.weight !== undefined && (
                <text
                  x={midX + textOffsetX}
                  y={midY + textOffsetY}
                  textAnchor="middle"
                  fontSize="14px" 
                  fontWeight="600" 
                  fill={edgeTextFill}
                   paintOrder="stroke" 
                   stroke={'hsl(var(--card))'} 
                   strokeWidth="3px" 
                   strokeLinecap="butt" 
                   strokeLinejoin="miter"
                   onClick={(e) => handleEdgeWeightClick(e, edge)}
                   className="cursor-pointer select-none"
                >
                  {edge.weight}
                </text>
              )}
            </g>
          );
        })}

        {/* Nodes */}
        {nodes.map(node => {
          const isAlgorithmVisitNode = highlightedNodes.has(node.id) && (currentAlgorithmStep?.type === 'visit-node' || currentAlgorithmStep?.type === 'traverse-edge');
          const isPathNode = currentPathNodes.has(node.id);
          const isStart = node.id === startNode;
          const isEnd = node.id === endNode;
          const isEdgeCreationActiveSource = node.id === edgeCreationSource;

          let nodeFill = 'hsl(var(--card))'; 
          let nodeStroke = 'hsl(var(--foreground))'; 
          let nodeStrokeWidth = 1.5;


          if (isPathNode) { 
            nodeFill = 'hsl(var(--accent))';
            nodeStroke = 'hsl(var(--accent))';
            nodeStrokeWidth = 2.5;
          } else if (isAlgorithmVisitNode) { 
             nodeFill = currentAlgorithmStep?.color ? currentAlgorithmStep.color : 'hsl(var(--primary))';
             nodeStroke = currentAlgorithmStep?.color ? currentAlgorithmStep.color : 'hsl(var(--primary))';
             nodeStrokeWidth = 2.5;
          }


          if (isStart) {
            if (!isPathNode && !isAlgorithmVisitNode) { 
                nodeFill = 'hsl(var(--accent)/0.3)'; 
            }
            nodeStroke = 'hsl(var(--accent))'; 
            nodeStrokeWidth = Math.max(nodeStrokeWidth, 2.5); 
          }
          if (isEnd) {
            if (!isPathNode && !isAlgorithmVisitNode) {
                nodeFill = 'hsl(var(--destructive)/0.3)'; 
            }
            nodeStroke = 'hsl(var(--destructive))'; 
            nodeStrokeWidth = Math.max(nodeStrokeWidth, 2.5);
          }
          
           
          if (!isPathNode && !isAlgorithmVisitNode && !isStart && !isEnd) {
             nodeFill = 'hsl(var(--card))'; 
             nodeStroke = 'hsl(var(--foreground))';
          }


          if (isEdgeCreationActiveSource) { 
            nodeStroke = 'hsl(var(--ring))'; 
            nodeStrokeWidth = 3;
            if (nodeFill === 'hsl(var(--card))') { 
                 nodeFill = 'hsl(var(--ring)/0.2)'; 
            }
          }
           nodeFill = 'hsl(0 0% 100%)'; 
           nodeStroke = 'hsl(0 0% 13%)'; 

          return (
            <g
              key={node.id}
              transform={`translate(${node.x}, ${node.y})`}
              onMouseDown={(e) => handleNodeMouseDown(e, node.id)}
              onMouseUp={(e) => handleNodeMouseUp(e, node.id)}
              onClick={(e) => handleNodeClick(e, node.id)}
              onContextMenu={(e) => handleNodeContextMenu(e, node.id)}
              onTouchStart={(e) => handleNodeMouseDown(e, node.id)}
              onTouchEnd={(e) => handleNodeMouseUp(e, node.id)}

              className={cn(
                "cursor-pointer group/node transition-opacity duration-150",
                selectedTool === 'pointer' && 'hover:opacity-80',
                selectedTool === 'add-edge' && (edgeCreationSource ? 'cursor-crosshair' : 'cursor-default'),
                isEdgeCreationActiveSource && 'animate-pulse'
              )}
            >
              <circle
                r={NODE_RADIUS}
                fill={nodeFill}
                stroke={nodeStroke}
                strokeWidth={nodeStrokeWidth}
                className='transition-all duration-150'
              />
              <text
                textAnchor="middle"
                dominantBaseline="middle"
                fontFamily="Arial, Helvetica, sans-serif"
                fontSize="16px"
                fontWeight="600"
                fill="#000000" 
                stroke="#000000"
                strokeWidth="0.5px" 
                paintOrder="stroke" 
                className="select-none pointer-events-none transition-colors duration-150"
              >
                {node.label}
              </text>
            </g>
          );
        })}
        {nodes.length === 0 && !edgeWeightPopoverOpen && (
          <foreignObject x="0" y="0" width="100%" height="100%" style={{ pointerEvents: 'none' }}>
            <div className="flex flex-col items-center justify-center h-full text-center pointer-events-none p-4 text-muted-foreground">
              <DraftingCompass className="w-24 h-24 text-muted-foreground/30 mb-6" data-ai-hint="compass sketch" />
              <h3 className="text-xl font-semibold mb-2">Kanavaca e Grafikut</h3>
              <p className="text-sm max-w-xs mb-2">
                Kliko në kanavacë për të shtuar një nyje. Për të fshirë, kliko me të djathtën mbi nyje.
              </p>
              <p className="text-sm max-w-xs">
                Përdor mjetin <PencilRuler className="inline h-4 w-4 text-accent align-text-bottom" /> &quot;Shto Brinjë&quot; ose zgjidh një sugjerim nga <Shapes className="inline h-4 w-4 text-accent align-text-bottom" /> &quot;Sugjerime Grafesh&quot;.
              </p>
            </div>
          </foreignObject>
        )}
      </svg>

      <Popover
        open={edgeWeightPopoverOpen}
        onOpenChange={(open) => {
            setEdgeWeightPopoverOpen(open);
            if (!open) {
               setEdgeCreationSource(null);
               setCurrentEdgeCandidate(null);
               setEdgeToEditId(null);
               setEdgeWeight(1);
            }
        }}
      >
        <PopoverTrigger asChild>
             <button style={{
                display: edgeWeightPopoverOpen ? 'block' : 'none',
                position: 'fixed',
                left: `${popoverPosition.x}px`,
                top: `${popoverPosition.y}px`,
                transform: 'translate(10px, 10px)',
                width: 1, height: 1, opacity: 0, pointerEvents: 'none'
             }}></button>
        </PopoverTrigger>
        <PopoverContent className="w-64 p-4 space-y-3" side="right" align="start" sideOffset={15}>
            <div className="space-y-1">
              <h4 className="font-medium leading-none text-sm">
                {edgeToEditId ? "Modifiko Peshën e Brinjës" : "Shto Peshën e Brinjës"}
              </h4>
              <p className="text-xs text-muted-foreground">
                {edgeToEditId
                    ? "Ndrysho peshën për brinjën e zgjedhur."
                    : (currentEdgeCandidate?.source === currentEdgeCandidate?.target
                        ? "Vendos peshën për lidhjen vetjake."
                        : "Vendos peshën për brinjën. Lëre 1 për graf pa peshë ose 0 nëse lejohet.")
                }
              </p>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="edge-weight" className="text-xs">Pesha</Label>
              <Input
                id="edge-weight"
                type="number"
                value={edgeWeight}
                onChange={(e) => {
                    const value = e.target.value;
                    if (value === "") {
                        setEdgeWeight(NaN); 
                    } else {
                        const numValue = parseInt(value, 10);
                        setEdgeWeight(isNaN(numValue) ? 0 : numValue); 
                    }
                }}
                className="h-8 text-sm"
                min="0" 
                autoFocus
                onKeyDown={(e) => { if (e.key === 'Enter') handleAddEdgeWithWeight(); }}
              />
            </div>
            <div className="flex justify-end gap-2">
                <Button variant="outline" size="sm" onClick={() => {
                    setEdgeWeightPopoverOpen(false);
                    setEdgeCreationSource(null);
                    setCurrentEdgeCandidate(null);
                    setEdgeToEditId(null);
                    setEdgeWeight(1);
                }}>Anulo</Button>
                <Button size="sm" onClick={handleAddEdgeWithWeight}>
                    {edgeToEditId ? "Ruaj" : "Shto Brinjë"}
                </Button>
            </div>
        </PopoverContent>
      </Popover>

      {currentAlgorithmStep?.type === 'message' && currentAlgorithmStep.message && (
        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 w-max max-w-[calc(100%-2rem)] bg-background/95 text-foreground p-2.5 px-4 rounded-lg shadow-xl text-xs sm:text-sm border border-border z-20 text-center">
          {currentAlgorithmStep.message}
        </div>
      )}
    </div>
  );
}

