// @ts-nocheck
'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion"
import { Separator } from '@/components/ui/separator';
import { Slider } from '@/components/ui/slider';
import { toast } from '@/hooks/use-toast';
import type { Node, Edge, AlgorithmType, SelectedToolType, EdgeDrawType } from '@/types/graph';
import { SlidersHorizontal, CirclePlus, Trash2, Play, Pointer, Network, Trash, Settings2, Search, Waypoints, Sprout, Shapes, LayoutGrid, GitFork, CircleDot, Binary, PlusSquare, Route, Star, TreeDeciduous, PalmtreeIcon, PencilRuler, Spline, Sheet, FileJson } from 'lucide-react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';
import { cn } from '@/lib/utils';


interface ControlsPanelProps {
  nodes: Node[];
  edges: Edge[];
  isDirected: boolean;
  onAddNode: () => void;
  onToggleDirected: (isDirected: boolean) => void;
  onRunAlgorithm: (algorithm: AlgorithmType, startNode?: string, endNode?: string) => void;
  onClearGraph: () => void;
  selectedTool: SelectedToolType;
  setSelectedTool: (tool: SelectedToolType) => void;
  startNode: string | null;
  setStartNode: (nodeId: string | null) => void;
  endNode: string | null;
  setEndNode: (nodeId: string | null) => void;
  animationSpeed: number;
  onAnimationSpeedChange: (speed: number) => void;
  onDrawSuggestedGraph: (suggestionType: string, customData?: { nodeCount?: number; graphType?: string }) => void;
  edgeDrawType: EdgeDrawType;
  setEdgeDrawType: (type: EdgeDrawType) => void;
  onGenerateFromMatrix: (matrixString: string) => void;
  onGenerateFromJSON: (jsonString: string) => void;
}

interface AlgorithmOption {
  value: AlgorithmType;
  label: string;
  needsStartNode: boolean;
  needsEndNode: boolean;
}

const algorithmCategories: {
  name: string;
  icon: React.ElementType;
  algorithms: AlgorithmOption[];
}[] = [
  {
    name: "Algoritmet Kërkuese/Kaluese",
    icon: Search,
    algorithms: [
      { value: "bfs", label: "BFS", needsStartNode: true, needsEndNode: false },
      { value: "dfs", label: "DFS", needsStartNode: true, needsEndNode: false },
    ],
  },
  {
    name: "Algoritmet e Rrugës më të Shkurtër",
    icon: Waypoints,
    algorithms: [
      { value: "dijkstra", label: "Dijkstra", needsStartNode: true, needsEndNode: true },
      { value: "a-star", label: "A* (A-yll)", needsStartNode: true, needsEndNode: true },
      { value: "bellman-ford", label: "Bellman-Ford", needsStartNode: true, needsEndNode: false },
      { value: "floyd-warshall", label: "Floyd-Warshall", needsStartNode: false, needsEndNode: false },
    ],
  },
  {
    name: "Algoritmet e Pemës Minimale Shtrirëse (MST)",
    icon: Sprout,
    algorithms: [
      { value: "kruskal", label: "Kruskal", needsStartNode: false, needsEndNode: false },
      { value: "prim", label: "Prim", needsStartNode: true, needsEndNode: false },
    ],
  },
];

const predefinedSuggestionOptions = [
  { type: 'complete-k4', label: 'Graf i Plotë Fiks (K4)', icon: LayoutGrid },
  { type: 'star-s5', label: 'Graf Yll Fiks (S5)', icon: Star },
  { type: 'cycle-c5', label: 'Graf Ciklik Fiks (C5)', icon: CircleDot },
  { type: 'simple-tree', label: 'Graf Pemë Fiks', icon: TreeDeciduous },
];

const customGraphTypeOptions: { value: string; label: string; icon: React.ElementType }[] = [
    { value: 'complete', label: 'Graf i Plotë', icon: LayoutGrid },
    { value: 'star', label: 'Graf Yll', icon: Star },
    { value: 'cycle', label: 'Graf Ciklik', icon: CircleDot },
    { value: 'tree', label: 'Graf Pemë', icon: TreeDeciduous }, // Changed label
    { value: 'path', label: 'Graf Rrugë', icon: Route },
];


export function ControlsPanel({
  nodes,
  edges,
  isDirected,
  onAddNode, 
  onToggleDirected,
  onRunAlgorithm,
  onClearGraph,
  selectedTool,
  setSelectedTool,
  startNode,
  setStartNode,
  endNode,
  setEndNode,
  animationSpeed,
  onAnimationSpeedChange,
  onDrawSuggestedGraph,
  edgeDrawType,
  setEdgeDrawType,
  onGenerateFromMatrix,
  onGenerateFromJSON,
}: ControlsPanelProps) {
  const [selectedAlgorithm, setSelectedAlgorithm] = useState<AlgorithmOption | null>(null);
  const [openMenus, setOpenMenus] = useState<Set<string>>(new Set());
  const [customNodeCount, setCustomNodeCount] = useState<number>(5);
  const [customGraphType, setCustomGraphType] = useState<string>('path');
  const [matrixInput, setMatrixInput] = useState<string>('');
  const [jsonInput, setJsonInput] = useState<string>('');

  const toggleMenu = (menuId: string) => {
    setOpenMenus(prev => {
      const next = new Set(prev);
      if (next.has(menuId)) {
        next.delete(menuId);
      } else {
        next.add(menuId);
      }
      return next;
    });
  };

  const handleSelectAlgorithm = (algo: AlgorithmOption) => {
    setSelectedAlgorithm(algo);
    if (!algo.needsStartNode) setStartNode(null);
    if (!algo.needsEndNode) setEndNode(null);
  };

  const handleRunAlgorithm = () => {
    if (!selectedAlgorithm) {
      toast({ title: 'Gabim', description: 'Ju lutem zgjidhni një algoritëm.', variant: 'destructive' });
      return;
    }
    if (nodes.length === 0 && (selectedAlgorithm.needsStartNode || selectedAlgorithm.value === 'floyd-warshall' || selectedAlgorithm.value === 'kruskal')) {
      toast({ title: 'Gabim', description: 'Ju lutem shtoni nyje në graf para se të ekzekutoni një algoritëm.', variant: 'destructive' });
      return;
    }
    if (selectedAlgorithm.needsStartNode && !startNode) {
      toast({ title: 'Gabim', description: 'Ju lutem zgjidhni një nyje fillestare.', variant: 'destructive' });
      return;
    }
    if (selectedAlgorithm.needsEndNode && !endNode) {
      toast({ title: 'Gabim', description: `Për algoritmin ${selectedAlgorithm.label}, ju lutem zgjidhni një nyje përfundimtare.`, variant: 'destructive' });
      return;
    }
    onRunAlgorithm(selectedAlgorithm.value, startNode, endNode);
  };

  const toolButtons = [
    { tool: 'pointer' as SelectedToolType, label: 'Zgjedhës', icon: Pointer, tooltip: "Zgjidh dhe lëviz (P)" },
    { tool: 'add-edge' as SelectedToolType, label: 'Shto Brinjë', icon: Network, tooltip: "Lidh nyjet (E)" },
  ];

  useEffect(() => {
    if (selectedAlgorithm) {
      if (!selectedAlgorithm.needsStartNode) setStartNode(null);
      if (!selectedAlgorithm.needsEndNode) setEndNode(null);
    }
  }, [selectedAlgorithm, setStartNode, setEndNode]);

  const handleCustomNodeCountChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const count = parseInt(event.target.value, 10);
    if (!isNaN(count) && count > 0 && count <= 50) { 
      setCustomNodeCount(count);
    } else if (event.target.value === "") {
      setCustomNodeCount(0); 
    }
  };

  const handleGenerateCustomGraph = () => {
    if (customNodeCount > 0 && customNodeCount <=50) {
      onDrawSuggestedGraph('custom-graph', { nodeCount: customNodeCount, graphType: customGraphType });
    } else {
      toast({ title: 'Vlerë e pavlefshme', description: 'Ju lutem shkruani një numër nyjesh midis 1 dhe 50.', variant: 'destructive' });
    }
  };

  const handleGenerateFromMatrixClick = () => {
    if (!matrixInput.trim()) {
        toast({ title: 'Matrica Boshe', description: 'Ju lutem shkruani matricën e fqinjësisë.', variant: 'destructive' });
        return;
    }
    onGenerateFromMatrix(matrixInput);
  };

  const handleGenerateFromJSONClick = () => {
    if (!jsonInput.trim()) {
        toast({ title: 'JSON Bosh', description: 'Ju lutem shkruani skriptën JSON.', variant: 'destructive' });
        return;
    }
    onGenerateFromJSON(jsonInput);
  };

  return (
    <>
      <Card className="h-full flex flex-col shadow-md rounded-lg border bg-card">
        <CardHeader className="p-3 pt-4">
          <CardTitle className="text-lg flex items-center gap-2">
            <Settings2 className="h-5 w-5 text-primary" aria-hidden="true"/>
            <span>Paneli Kontrollit</span>
          </CardTitle>
          <CardDescription className="text-xs">Menaxho grafikun dhe ekzekuto algoritmet.</CardDescription>
        </CardHeader>

        <CardContent className="flex-grow space-y-3 overflow-y-auto p-3 custom-scrollbar">
          <Accordion
            type="multiple"
            className="w-full space-y-2"
            value={Array.from(openMenus)}
            onValueChange={(values) => setOpenMenus(new Set(values))}
          >
            <AccordionItem value="graph-tools-accordion" className="border-b-0">
              <AccordionTrigger 
                className="text-xs sm:text-sm hover:no-underline py-2 px-2 bg-muted/30 rounded-md data-[state=open]:bg-muted data-[state=open]:text-foreground font-medium"
              >
                <div className="flex items-center gap-2 text-muted-foreground data-[state=open]:text-foreground">
                  <PencilRuler className="h-4 w-4" /> Mjetet e Grafikut
                </div>
              </AccordionTrigger>
              <AccordionContent className="pt-1">
                <div className="grid grid-cols-2 gap-1.5 p-1">
                  {toolButtons.map(({ tool, label, icon: Icon, tooltip }) => (
                    <Tooltip key={tool} delayDuration={300}>
                      <TooltipTrigger asChild>
                        <Button
                          variant={selectedTool === tool ? 'secondary' : 'outline'}
                          size="default"
                          onClick={() => setSelectedTool(tool)}
                          className="flex items-center gap-2 w-full justify-start text-xs h-auto py-1.5 px-2 sm:text-sm sm:py-2 sm:px-3 sm:h-10"
                          aria-label={label}
                        >
                          <Icon className="h-4 w-4" aria-hidden="true" />
                          <span className="truncate">{label}</span>
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent side="right" sideOffset={5} className="text-xs">
                        <p>{tooltip}</p>
                      </TooltipContent>
                    </Tooltip>
                  ))}
                </div>
                {selectedTool === 'add-edge' && (
                  <div className="mt-2 p-2 border rounded-md bg-muted/20">
                    <Label className="text-xs sm:text-sm mb-1.5 block">Lloji i Lidhjes së Brinjës:</Label>
                    <RadioGroup
                      value={edgeDrawType}
                      onValueChange={(value: EdgeDrawType) => setEdgeDrawType(value)}
                      className="flex flex-col space-y-1"
                    >
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="straight" id="edge-straight" />
                        <Label htmlFor="edge-straight" className="text-xs sm:text-sm font-normal cursor-pointer">Lidhje e Drejtë</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="curved" id="edge-curved" />
                        <Label htmlFor="edge-curved" className="text-xs sm:text-sm font-normal cursor-pointer">Lidhje e Lakuar</Label>
                      </div>
                    </RadioGroup>
                  </div>
                )}
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="graph-settings-accordion" className="border-b-0">
              <AccordionTrigger 
                className="text-xs sm:text-sm hover:no-underline py-2 px-2 bg-muted/30 rounded-md data-[state=open]:bg-muted data-[state=open]:text-foreground font-medium"
              >
                <div className="flex items-center gap-2 text-muted-foreground data-[state=open]:text-foreground">
                  <Binary className="h-4 w-4" /> Cilësimet e Grafit
                </div>
              </AccordionTrigger>
              <AccordionContent className="pt-1">
                <div className="flex items-center rounded-md border p-2.5 shadow-sm bg-card justify-between m-1">
                    <Label htmlFor="directed-graph" className="text-xs sm:text-sm">Graf i Drejtuar?</Label>
                    <Switch
                    id="directed-graph"
                    checked={isDirected}
                    onCheckedChange={onToggleDirected}
                    aria-label="Kalo në graf të drejtuar ose të padrejtuar"
                    />
                </div>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="suggestions-accordion" className="border-b-0">
              <AccordionTrigger 
                className="text-xs sm:text-sm hover:no-underline py-2 px-2 bg-muted/30 rounded-md data-[state=open]:bg-muted data-[state=open]:text-foreground font-medium"
              >
                <div className="flex items-center gap-2 text-muted-foreground data-[state=open]:text-foreground">
                  <Shapes className="h-4 w-4" /> Sugjerimet e Grafeve
                </div>
              </AccordionTrigger>
              <AccordionContent className="pt-1">
                <div className="grid grid-cols-1 gap-1 p-1">
                  {predefinedSuggestionOptions.map((suggestion) => (
                    <Button
                      key={suggestion.type}
                      variant="ghost"
                      size="sm"
                      className="w-full justify-start text-xs sm:text-sm"
                      onClick={() => onDrawSuggestedGraph(suggestion.type)}
                    >
                      <suggestion.icon className="h-4 w-4 mr-2" />
                      {suggestion.label}
                    </Button>
                  ))}
                   <Separator className="my-2" />
                   <div className="space-y-2 p-1">
                     <Label htmlFor="custom-node-count" className="text-xs sm:text-sm block mb-1">Gjenero Graf të Personalizuar:</Label>
                     <div className="flex items-center gap-2">
                       <Input
                         id="custom-node-count"
                         type="number"
                         value={customNodeCount === 0 && nodes.length === 0 ? "" : customNodeCount}
                         onChange={handleCustomNodeCountChange}
                         min="1"
                         max="50"
                         className="h-8 text-sm w-20"
                         placeholder="Nr.Nyjeve"
                       />
                        <Select value={customGraphType} onValueChange={setCustomGraphType}>
                            <SelectTrigger id="custom-graph-type-select" aria-label="Zgjidh llojin e grafit" className="text-xs sm:text-sm h-8 flex-1">
                                <SelectValue placeholder="Lloji i Grafit" />
                            </SelectTrigger>
                            <SelectContent>
                                {customGraphTypeOptions.map(option => (
                                <SelectItem key={option.value} value={option.value} className="text-xs sm:text-sm">
                                    <div className="flex items-center gap-2">
                                        <option.icon className="h-4 w-4" />
                                        {option.label}
                                    </div>
                                </SelectItem>
                                ))}
                            </SelectContent>
                        </Select>
                     </div>
                     <Button
                         variant="outline"
                         size="sm"
                         className="w-full text-xs sm:text-sm mt-2"
                         onClick={handleGenerateCustomGraph}
                         disabled={customNodeCount <= 0 || customNodeCount > 50}
                       >
                         <PlusSquare className="h-4 w-4 mr-2" />
                         Gjenero Grafin e Personalizuar
                       </Button>
                   </div>
                </div>
              </AccordionContent>
            </AccordionItem>

             <AccordionItem value="matrix-input-accordion" className="border-b-0">
              <AccordionTrigger 
                className="text-xs sm:text-sm hover:no-underline py-2 px-2 bg-muted/30 rounded-md data-[state=open]:bg-muted data-[state=open]:text-foreground font-medium"
              >
                <div className="flex items-center gap-2 text-muted-foreground data-[state=open]:text-foreground">
                  <Sheet className="h-4 w-4" /> Gjenero nga Matrica
                </div>
              </AccordionTrigger>
              <AccordionContent className="pt-1">
                <Label htmlFor="matrix-input-area" className="text-xs sm:text-sm">Fut Matricën e Fqinjësisë (numra të ndarë me hapësirë/presje, rreshta me newline):</Label>
                <Textarea
                    id="matrix-input-area"
                    value={matrixInput}
                    onChange={(e) => setMatrixInput(e.target.value)}
                    placeholder={"Shembull:\n0 1 Inf\n1 0 5\nInf 5 0"}
                    className="text-xs sm:text-sm min-h-[80px]"
                />
                <Button onClick={handleGenerateFromMatrixClick} variant="outline" size="sm" className="w-full text-xs sm:text-sm">
                    <PlusSquare className="h-4 w-4 mr-2" /> Gjenero Grafikun
                </Button>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="json-input-accordion" className="border-b-0">
              <AccordionTrigger 
                className="text-xs sm:text-sm hover:no-underline py-2 px-2 bg-muted/30 rounded-md data-[state=open]:bg-muted data-[state=open]:text-foreground font-medium"
              >
                <div className="flex items-center gap-2 text-muted-foreground data-[state=open]:text-foreground">
                  <FileJson className="h-4 w-4" /> Gjenero nga JSON
                </div>
              </AccordionTrigger>
              <AccordionContent className="pt-1">
                <Label htmlFor="json-input-area" className="text-xs sm:text-sm">Fut Skriptën JSON:</Label>
                <Textarea
                    id="json-input-area"
                    value={jsonInput}
                    onChange={(e) => setJsonInput(e.target.value)}
                    placeholder={'Shembull:\n{\n  "nodes": [{"id":"n1", "label":"A", "x":50, "y":50}],\n  "edges": [{"id":"e1", "source":"n1", "target":"n1", "weight":1}],\n  "isDirected": false\n}'}
                    className="text-xs sm:text-sm min-h-[100px]"
                />
                <Button onClick={handleGenerateFromJSONClick} variant="outline" size="sm" className="w-full text-xs sm:text-sm">
                    <PlusSquare className="h-4 w-4 mr-2" /> Gjenero Grafikun
                </Button>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="algorithms-accordion" className="border-b-0">
              <AccordionTrigger 
                className="text-xs sm:text-sm hover:no-underline py-2 px-2 bg-muted/30 rounded-md data-[state=open]:bg-muted data-[state=open]:text-foreground font-medium"
              >
                <div className="flex items-center gap-2 text-muted-foreground data-[state=open]:text-foreground">
                  <GitFork className="h-4 w-4" /> Ekzekuto Algoritmin
                </div>
              </AccordionTrigger>
              <AccordionContent className="pt-1">
                <Accordion
                  type="multiple"
                  className="w-full space-y-0.5"
                  value={Array.from(openMenus).filter(id => id.startsWith('category-'))}
                  onValueChange={(values) => {
                    setOpenMenus(prev => {
                      const next = new Set(prev);
                      // Remove all category items first
                      Array.from(prev).forEach(id => {
                        if (id.startsWith('category-')) next.delete(id);
                      });
                      // Add the new values
                      values.forEach(id => next.add(id));
                      return next;
                    });
                  }}
                >
                  {algorithmCategories.map((category, index) => (
                    <AccordionItem value={`category-${index}`} key={category.name} className="border-b-0">
                      <AccordionTrigger 
                        className="text-xs sm:text-sm hover:no-underline py-1.5 px-2 bg-muted/20 hover:bg-muted/40 rounded-md data-[state=open]:bg-accent data-[state=open]:text-accent-foreground"
                      >
                        <div className="flex items-center gap-2">
                          <category.icon className="h-4 w-4" />
                          {category.name}
                        </div>
                      </AccordionTrigger>
                      <AccordionContent className="pt-0.5 pb-0">
                        <div className="grid grid-cols-1 gap-0.5 p-0.5">
                          {category.algorithms.map((algo) => (
                            <Button
                              key={algo.value}
                              variant={selectedAlgorithm?.value === algo.value ? "default" : "ghost"}
                              size="sm"
                              className="w-full justify-start text-xs sm:text-sm h-auto py-1.5"
                              onClick={() => handleSelectAlgorithm(algo)}
                            >
                              {algo.label}
                            </Button>
                          ))}
                        </div>
                      </AccordionContent>
                    </AccordionItem>
                  ))}
                </Accordion>

                {selectedAlgorithm?.label && (
                <div className="p-2 mt-1.5 border rounded-md bg-muted/20 text-center">
                    <p className="text-xs text-muted-foreground">Algoritmi i zgjedhur: <span className="font-semibold text-primary">{selectedAlgorithm.label}</span></p>
                </div>
                )}

                {nodes.length > 0 && selectedAlgorithm?.needsStartNode && (
                <Select value={startNode || ""} onValueChange={setStartNode}>
                    <SelectTrigger id="start-node-select" aria-label="Zgjidh nyjen fillestare" className="text-xs sm:text-sm mt-1.5">
                    <SelectValue placeholder="Nyja Fillestare" />
                    </SelectTrigger>
                    <SelectContent>
                    {nodes.map(node => (
                        <SelectItem key={node.id} value={node.id} className="text-xs sm:text-sm">{node.label}</SelectItem>
                    ))}
                    </SelectContent>
                </Select>
                )}

                {nodes.length > 0 && selectedAlgorithm?.needsEndNode && startNode && (
                <Select value={endNode || ""} onValueChange={setEndNode}>
                    <SelectTrigger id="end-node-select" aria-label="Zgjidh nyjen përfundimtare" className="text-xs sm:text-sm mt-1.5">
                    <SelectValue placeholder="Nyja Përfundimtare" />
                    </SelectTrigger>
                    <SelectContent>
                    {nodes.map(node => (
                        <SelectItem key={node.id} value={node.id} disabled={node.id === startNode} className="text-xs sm:text-sm">
                        {node.label}
                        </SelectItem>
                    ))}
                    </SelectContent>
                </Select>
                )}
                <Button
                    onClick={handleRunAlgorithm}
                    className="w-full text-xs sm:text-sm mt-1.5"
                    size="default"
                    disabled={
                    !selectedAlgorithm ||
                    (nodes.length === 0 && (selectedAlgorithm.needsStartNode || selectedAlgorithm.value === 'floyd-warshall' || selectedAlgorithm.value === 'kruskal')) ||
                    (selectedAlgorithm.needsStartNode && !startNode) ||
                    (selectedAlgorithm.needsEndNode && !endNode)
                    }
                    aria-label="Ekzekuto Algoritmin"
                >
                    <Play className="h-4 w-4 mr-1" aria-hidden="true"/> Ekzekuto
                </Button>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="animation-settings-accordion" className="border-b-0">
              <AccordionTrigger 
                className="text-xs sm:text-sm hover:no-underline py-2 px-2 bg-muted/30 rounded-md data-[state=open]:bg-muted data-[state=open]:text-foreground font-medium"
              >
                <div className="flex items-center gap-2 text-muted-foreground data-[state=open]:text-foreground">
                  <SlidersHorizontal className="h-4 w-4"/> Shpejtësia e Animacionit
                </div>
              </AccordionTrigger>
              <AccordionContent className="pt-1">
                <div className="flex items-center gap-3 p-2.5 rounded-md border bg-card shadow-sm m-1">
                  <Slider
                      value={[animationSpeed]}
                      max={3000}
                      min={200}
                      step={50}
                      onValueChange={(value) => onAnimationSpeedChange(value[0])}
                      className="flex-1"
                      aria-label="Rregullo shpejtësinë e animacionit"
                  />
                  <span className="text-xs text-muted-foreground w-14 text-center tabular-nums">
                      {(animationSpeed / 1000).toFixed(1)} s
                  </span>
                </div>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </CardContent>
        <CardFooter className="p-3 border-t mt-auto">
            <Button
              onClick={onClearGraph}
              variant="destructive"
              className="w-full text-xs sm:text-sm"
              size="default"
              aria-label="Pastro Grafikun"
              >
                <Trash2 className="h-4 w-4 mr-1" aria-hidden="true"/> Pastro Grafikun
            </Button>
        </CardFooter>
      </Card>
    </>
  );
}

