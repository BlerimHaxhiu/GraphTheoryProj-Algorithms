
'use client';

import type { Node, Edge, GraphStats } from '@/types/graph';
import { calculateGraphStats } from '@/lib/graph-utils';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { BarChart3, Component, Shapes, Binary, CheckCircle2, XCircle } from 'lucide-react';
import { useMemo } from 'react';

interface GraphStatsPanelProps {
  nodes: Node[];
  edges: Edge[];
  isDirected: boolean;
}

export function GraphStatsPanel({ nodes, edges, isDirected }: GraphStatsPanelProps) {
  const stats: GraphStats = useMemo(() => calculateGraphStats(nodes, edges, isDirected), [nodes, edges, isDirected]);

  const statItems = [
    { label: 'Numri i Nyjeve', value: stats.nodesCount, icon: Shapes },
    { label: 'Numri i Brinjëve', value: stats.edgesCount, icon: Binary }, // Using Binary for edges as an abstract representation
    { label: 'Dendësia', value: stats.density, icon: BarChart3 },
    { label: 'Komponentët e Lidhur', value: stats.connectedComponents, icon: Component },
    { 
      label: 'Grafi i Plotë?', 
      value: stats.isComplete ? 'Po' : 'Jo', 
      icon: stats.isComplete ? CheckCircle2 : XCircle,
      color: stats.isComplete ? 'text-green-500' : 'text-red-500'
    },
  ];

  return (
    <Card className="shadow-lg">
      <CardHeader className="pb-2 pt-4 px-4">
        <CardTitle className="text-lg flex items-center">
          <BarChart3 className="h-5 w-5 mr-2 text-primary" />
          Statistikat e Grafit
        </CardTitle>
      </CardHeader>
      <CardContent className="px-4 pb-4">
        {nodes.length === 0 ? (
          <p className="text-sm text-muted-foreground text-center py-4">Shtoni nyje dhe brinjë për të parë statistikat.</p>
        ) : (
          <ul className="space-y-2 text-sm">
            {statItems.map(item => (
              <li key={item.label} className="flex justify-between items-center p-2 bg-muted/30 rounded-md">
                <span className="flex items-center">
                  <item.icon className={`h-4 w-4 mr-2 ${item.color || 'text-muted-foreground'}`} />
                  {item.label}:
                </span>
                <span className={`font-semibold ${item.color || 'text-foreground'}`}>{item.value}</span>
              </li>
            ))}
          </ul>
        )}
      </CardContent>
    </Card>
  );
}
