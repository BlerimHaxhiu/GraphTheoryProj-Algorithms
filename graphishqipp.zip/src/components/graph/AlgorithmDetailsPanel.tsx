
'use client';

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ListTree } from 'lucide-react';

export function AlgorithmDetailsPanel() {
  return (
    <Card className="shadow-lg">
      <CardHeader className="pb-2 pt-4 px-4">
        <CardTitle className="text-lg flex items-center">
          <ListTree className="h-5 w-5 mr-2 text-primary" />
          Analiza e Detajuar e Algoritmit
        </CardTitle>
      </CardHeader>
      <CardContent className="px-4 pb-4">
        <p className="text-sm text-muted-foreground text-center py-4">
          Detajet specifike të ekzekutimit të algoritmit (si kostoja totale, nyjet e vizituara, etj.) do të shfaqen këtu pasi të ekzekutohet një algoritëm.
        </p>
        {/* This panel will be populated with more details in a future update. */}
      </CardContent>
    </Card>
  );
}
