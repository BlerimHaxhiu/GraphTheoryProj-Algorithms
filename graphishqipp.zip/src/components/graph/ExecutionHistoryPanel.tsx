
'use client';

import type { ExecutionLogEntry } from '@/types/graph';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { History } from 'lucide-react';
import { format } from 'date-fns';
import { sq } from 'date-fns/locale'; // Albanian locale for date-fns

interface ExecutionHistoryPanelProps {
  history: ExecutionLogEntry[];
}

export function ExecutionHistoryPanel({ history }: ExecutionHistoryPanelProps) {
  return (
    <Card className="shadow-lg h-[300px] flex flex-col"> {/* Added fixed height and flex structure */}
      <CardHeader className="pb-2 pt-4 px-4">
        <CardTitle className="text-lg flex items-center">
          <History className="h-5 w-5 mr-2 text-primary" />
          Historiku i Ekzekutimeve
        </CardTitle>
      </CardHeader>
      <CardContent className="px-4 pb-4 flex-grow overflow-hidden"> {/* Allow content to grow and hide overflow for ScrollArea */}
        {history.length === 0 ? (
          <p className="text-sm text-muted-foreground text-center py-4 h-full flex items-center justify-center">
            Nuk ka ekzekutime të regjistruara.
          </p>
        ) : (
          <ScrollArea className="h-full">
            <ul className="space-y-2 text-xs">
              {history.slice().reverse().map((entry) => ( // Show newest first
                <li key={entry.id} className="p-2 bg-muted/30 rounded-md">
                  <div className="font-semibold text-primary">{entry.algorithm.toUpperCase()}</div>
                  <div className="text-muted-foreground">
                    {format(entry.startTime, "d MMM yyyy, HH:mm:ss", { locale: sq })} - {format(entry.endTime, "HH:mm:ss", { locale: sq })}
                  </div>
                  <div>
                    {entry.startNodeLabel && `Fillimi: ${entry.startNodeLabel}`}
                    {entry.endNodeLabel && `, Fundi: ${entry.endNodeLabel}`}
                  </div>
                  <div className="italic">{entry.resultSummary}</div>
                </li>
              ))}
            </ul>
          </ScrollArea>
        )}
      </CardContent>
    </Card>
  );
}
