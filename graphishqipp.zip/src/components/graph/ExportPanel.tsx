
'use client';

import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Save, Download, Image as ImageIcon } from 'lucide-react';

interface ExportPanelProps {
  onSaveGraph: () => void;
  onExportJSON: () => void;
  onExportPNG: () => void;
}

export function ExportPanel({ onSaveGraph, onExportJSON, onExportPNG }: ExportPanelProps) {
  return (
    <Card className="shadow-lg">
      <CardHeader className="pb-2 pt-4 px-4">
        <CardTitle className="text-lg flex items-center">
          <Download className="h-5 w-5 mr-2 text-primary" />
          Ruaj & Eksporto
        </CardTitle>
      </CardHeader>
      <CardContent className="px-4 pb-4 space-y-2">
        <Button onClick={onSaveGraph} className="w-full justify-start" variant="outline">
          <Save className="h-4 w-4 mr-2" />
          Ruaj Grafikun (localStorage)
        </Button>
        <Button onClick={onExportJSON} className="w-full justify-start" variant="outline">
          <Download className="h-4 w-4 mr-2" />
          Eksporto si JSON
        </Button>
        <Button onClick={onExportPNG} className="w-full justify-start" variant="outline">
          <ImageIcon className="h-4 w-4 mr-2" />
          Eksporto si Imazh (PNG)
        </Button>
      </CardContent>
    </Card>
  );
}
