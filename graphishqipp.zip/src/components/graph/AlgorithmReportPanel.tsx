
'use client';

import type { AlgorithmStep, Node, Edge } from '@/types/graph';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { cn } from '@/lib/utils';
import { MessageSquare, Shuffle, LocateFixed, Waypoints, RefreshCcw, AlertTriangle, ListChecks, PlayCircle } from 'lucide-react';

interface AlgorithmReportPanelProps {
  reportLog: AlgorithmStep[];
  nodes: Node[];
  edges: Edge[]; 
}

const getNodeLabel = (nodeId: string | undefined, nodes: Node[]): string => {
  if (!nodeId) return 'Nyje e panjohur';
  const node = nodes.find(n => n.id === nodeId);
  return node ? node.label : (nodeId.length > 6 ? nodeId.substring(0,6) + '...' : nodeId );
};

export function AlgorithmReportPanel({ reportLog, nodes, edges }: AlgorithmReportPanelProps) {
  const getMessageIconAndStyle = (step: AlgorithmStep) => {
    let IconComponent;
    let textColorClass = 'text-foreground';
    let bgColorClass = 'bg-card hover:bg-muted/50';

    switch (step.type) {
      case 'visit-node':
        IconComponent = LocateFixed;
        textColorClass = 'text-blue-600 dark:text-blue-400';
        bgColorClass = 'bg-blue-500/10 hover:bg-blue-500/20';
        break;
      case 'traverse-edge':
        IconComponent = Shuffle;
        textColorClass = 'text-green-600 dark:text-green-400';
        bgColorClass = 'bg-green-500/10 hover:bg-green-500/20';
        break;
      case 'highlight-path':
        IconComponent = Waypoints;
        textColorClass = 'text-accent-foreground';
        bgColorClass = 'bg-accent/20 hover:bg-accent/30';
        break;
      case 'reset':
        IconComponent = RefreshCcw;
        textColorClass = 'text-muted-foreground';
        bgColorClass = 'bg-muted/20 hover:bg-muted/30';
        break;
      case 'message':
        IconComponent = MessageSquare;
        textColorClass = 'text-foreground/90';
        bgColorClass = 'bg-muted/30 hover:bg-muted/40';
        if (step.message?.toLowerCase().includes('gabim') || step.message?.toLowerCase().includes('error')) {
          IconComponent = AlertTriangle;
          textColorClass = 'text-destructive';
          bgColorClass = 'bg-destructive/10 hover:bg-destructive/20';
        }
        break;
      default:
        IconComponent = MessageSquare; 
        textColorClass = 'text-muted-foreground'; 
        bgColorClass = 'bg-muted/20 hover:bg-muted/30';
    }
    return { IconComponent, textColorClass, bgColorClass };
  };

  const formatStepMessage = (step: AlgorithmStep): string => {
    switch (step.type) {
      case 'visit-node':
        return `Vizitohet nyja: ${getNodeLabel(step.nodeId, nodes)}`;
      case 'traverse-edge': {
        const edge = edges.find(e => e.id === step.edgeId);
        const sourceNodeLabel = edge ? getNodeLabel(edge.source, nodes) : (step.highlightSourceNodeId ? getNodeLabel(step.highlightSourceNodeId, nodes) : 'Panjohur');
        const targetNodeLabel = getNodeLabel(step.nodeId, nodes); 
        return `Kalohet brinja: ${sourceNodeLabel} → ${targetNodeLabel}`;
      }
      case 'highlight-path':
        return `Rruga finale: ${step.path?.map(id => getNodeLabel(id, nodes)).join(' → ') || 'Bosh'}`;
      default: 
        return step.message || 'Hap i papërcaktuar.';
    }
  };

  return (
    <Card className="flex flex-col shadow-md h-full overflow-hidden">
      <CardHeader className="py-3 px-4 border-b">
        <CardTitle className="text-md sm:text-lg flex items-center gap-2">
          <ListChecks className="h-5 w-5 text-primary" />
          Raporti i Algoritmit
          </CardTitle>
      </CardHeader>
      <CardContent className="flex-grow p-0 overflow-hidden">
        <ScrollArea className="h-full w-full p-2 sm:p-3">
          {reportLog.length === 0 ? (
            <div className="text-center text-muted-foreground h-full flex flex-col items-center justify-center p-4">
              <PlayCircle className="w-12 h-12 text-muted-foreground/30 mb-3" />
              <span className="text-sm">Shfaqet një raport mbi ekzekutimin e një algoritmi.</span>
               <span className="text-xs">
                {nodes.length === 0 ? "Shtoni nyje dhe pastaj ekzekutoni një algoritëm." : "Ekzekutoni një algoritëm për të parë hapat."}
               </span>
            </div>
          ) : (
            <ul className="space-y-1.5 sm:space-y-2">
              {reportLog.map((step) => { // Removed index, use step.id for key
                const { IconComponent, textColorClass, bgColorClass } = getMessageIconAndStyle(step);
                const messageContent = formatStepMessage(step);

                return (
                  <li 
                    key={step.id} // Use unique step ID as key
                    className={cn(
                      "flex items-start text-xs sm:text-sm p-2 rounded-md transition-colors", 
                      bgColorClass
                    )}
                  >
                    <IconComponent className={cn("h-3.5 w-3.5 sm:h-4 sm:w-4 mr-2 mt-0.5 shrink-0", textColorClass)} aria-hidden="true" />
                    <span className={cn("flex-grow", textColorClass)}>{messageContent}</span>
                  </li>
                );
              })}
            </ul>
          )}
        </ScrollArea>
      </CardContent>
    </Card>
  );
}
