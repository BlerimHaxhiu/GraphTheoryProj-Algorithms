import { config } from 'dotenv';
config();

// import '@/ai/flows/compare-algorithms-flow.ts'; // Removed as this flow is deleted
// import '@/ai/flows/recommend-algorithm-flow.ts'; // Removed as this flow is deleted
