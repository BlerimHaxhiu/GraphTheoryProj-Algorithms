// src/app/layout.tsx
import type { Metadata } from 'next';
import { Inter } from 'next/font/google';
import './globals.css';
import { TooltipProvider } from "@/components/ui/tooltip";

const inter = Inter({
  subsets: ['latin'],
});

export const metadata: Metadata = {
  title: 'Aplikacion për Analizën e Algoritmeve të Grafeve',
  description: 'Një mjet i fuqishëm për vizualizimin dhe analizën e grafeve.',
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="sq" className="h-full">
      <body className={`${inter.className} antialiased`}>
        <TooltipProvider>
          {children}
        </TooltipProvider>
      </body>
    </html>
  );
}