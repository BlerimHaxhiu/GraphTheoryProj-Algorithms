"use client";
import React, { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { motion } from "framer-motion";

// Simple cn utility for className joining
function cn(...classes: (string | undefined | false)[]) {
  return classes.filter(Boolean).join(" ");
}

// tsparticles imports
import type { Engine } from "@tsparticles/engine";
import Particles, { initParticlesEngine } from "@tsparticles/react";
import { loadSlim } from "@tsparticles/slim";
import type { ISourceOptions } from "@tsparticles/engine";

export default function LandingPage() {
  const [init, setInit] = useState(false);

  // Initialize tsparticles engine
  useEffect(() => {
    initParticlesEngine(async (engine: Engine) => {
      try {
        await loadSlim(engine);
        setInit(true);
      } catch (error) {
        console.error("Particles: Error during loadSlim:", error);
      }
    }).catch((error) => {
      console.error("Particles: Error initializing tsparticles engine:", error);
    });
  }, []);

  const particlesOptions = useMemo<ISourceOptions>(
    () => ({
      background: {
        color: {
          value: "#0b0b0b",
        },
      },
      fpsLimit: 60,
      interactivity: {
        events: {
          onHover: {
            enable: true,
            mode: "grab" as const,
          },
          onClick: {
            enable: true,
            mode: "push" as const,
          },
        },
        modes: {
          grab: {
            distance: 140,
            links: {
              opacity: 0.4,
            },
          },
          push: {
            quantity: 3,
          },
        },
      },
      particles: {
        color: {
          value: "#32cd72",
        },
        links: {
          color: "#32cd72",
          distance: 150,
          enable: true,
          opacity: 0.2,
          width: 1,
        },
        collisions: {
          enable: true,
        },
        move: {
          direction: "none" as const,
          enable: true,
          outModes: {
            default: "bounce" as const,
          },
          random: false,
          speed: 0.5,
          straight: false,
        },
        number: {
          density: {
            enable: true,
            area: 800,
          },
          value: 70,
        },
        opacity: {
          value: 0.4,
        },
        shape: {
          type: "circle" as const,
        },
        size: {
          value: { min: 1, max: 3 },
        },
      },
      detectRetina: true,
    }),
    []
  );

  const cardData = [
    {
      title: "Ndërtim & Personalizim Fleksibël i Grafeve",
      desc: "Ndërtoni grafe intuitivisht me klikime ose gjeneroni struktura komplekse nga matrica e fqinjësisë apo skripta JSON. Shtoni nyje dhe brinjë (të drejta ose të lakuara) me pesha, zgjidhni grafe të drejtuara/padrejtuara, dhe përdorni sugjerime të gatshme (K4, Yll, Cikël, Pemë) apo krijoni grafe të personalizuara sipas numrit dhe llojit të dëshiruar.",
      dataAiHint: "interactive graph",
    },
    {
      title: "Ekzekutim & Analizë e Thelluar e Algoritmeve",
      desc: "Eksploroni një suitë të plotë algoritmesh: kërkuese/kaluese (BFS, DFS), të rrugës më të shkurtër (Dijkstra, Bellman-Ford, A*, Floyd-Warshall), dhe të pemës minimale mbuluese (Kruskal, Prim). Ndiqni ekzekutimin hap pas hapi, kuptoni teorinë prapa tyre, dhe vëzhgoni statistikat e grafikut e matricën e fqinjësisë në kohë reale.",
      dataAiHint: "algorithm analysis",
    },
    {
      title: "Vlerësim, Ruajtje & Eksportim i Punës Tuaj",
      desc: "Analizoni dhe krahasoni performancën e algoritmeve të ndryshme bazuar në kohën e ekzekutimit dhe kompleksitetin teorik. Ruani grafikun tuaj në memorien lokale, eksportojeni si skedar JSON për përdorim të mëtejshëm, ose si imazh PNG me cilësi të lartë (WYSIWYG) për prezantime dhe raporte.",
      dataAiHint: "data export",
    },
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
        delayChildren: 0.1,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        type: "spring",
        stiffness: 100,
        damping: 10,
      },
    },
  };

  return (
    <div className="relative min-h-screen bg-[#0b0b0b] text-[#e6e6e6] font-['Inter',_sans-serif] leading-relaxed flex flex-col items-center overflow-hidden tracking-wide">
      {init && (
        <Particles
          id="tsparticles-landing"
          options={particlesOptions}
          className="absolute inset-0 z-0"
        />
      )}

      <main className="relative flex-1 flex flex-col items-center w-full max-w-[1000px] mx-auto px-6 py-8 z-10">
        <motion.div
          className="w-full text-center"
          initial="hidden"
          animate="visible"
          variants={containerVariants}
        >
          <motion.div variants={itemVariants} className="mb-10">
            <h1 className="text-4xl font-extrabold text-[#32cd72] drop-shadow-lg mb-4">
              Aplikacion për Analizën e Algoritmeve të Grafeve
            </h1>
            <p className="text-lg text-[#cfcfcf] max-w-[800px] mx-auto">
              Zbuloni fuqinë e teorisë së grafeve dhe algoritmeve me këtë mjet interaktiv. Ndërtoni, vizualizoni, dhe analizoni grafet me një gamë të gjerë funksionalitetesh: nga krijimi manual apo i automatizuar i grafeve, deri te ekzekutimi i detajuar i algoritmeve themelore dhe të avancuara. Kuptoni, krahasoni, ruani dhe ndani punën tuaj me lehtësi.
            </p>
          </motion.div>

          <motion.div
            className="grid grid-cols-1 md:grid-cols-3 gap-4 w-full"
            variants={containerVariants}
          >
            {cardData.map(({ title, desc, dataAiHint }, i) => (
              <motion.div
                key={i}
                className="bg-white/5 backdrop-blur-md border border-white/10 rounded-xl p-5 shadow-lg"
                data-ai-hint={dataAiHint}
                variants={itemVariants}
                whileHover={{
                  scale: 1.02,
                  boxShadow: "0px 0px 20px rgba(50, 205, 114, 0.2)",
                  y: -2,
                }}
                transition={{ type: "spring", stiffness: 300, damping: 20 }}
              >
                <h3 className="text-[#32cd72] text-lg font-semibold mb-2">{title}</h3>
                <p className="text-[#b5b5b5] text-sm">{desc}</p>
              </motion.div>
            ))}
          </motion.div>

          <motion.div
            variants={itemVariants}
            className="mt-10"
            whileHover={{ scale: 1.03 }}
            transition={{ type: "spring", stiffness: 300 }}
          >
            <Link
              href="/app"
              className={cn(
                "inline-flex items-center gap-2 text-[#32cd72] hover:text-white bg-white/5 border border-[#32cd72] rounded-full px-6 py-2.5 text-base font-semibold transition-all duration-300 hover:bg-[#32cd72]/20 focus:outline-none focus:ring-2 focus:ring-[#32cd72] focus:ring-offset-2 focus:ring-offset-[#0b0b0b]"
              )}
            >
              Filloni Tani <ArrowRight size={20} />
            </Link>
          </motion.div>
        </motion.div>
      </main>

      <footer className="relative w-full max-w-[1000px] text-center py-6 text-sm text-gray-500 z-10 px-6">
        <p>
          © {new Date().getFullYear()}{" "}
          <span className="text-[#32cd72] font-medium">
            Aplikacion për Analizën e Algoritmeve të Grafeve
          </span>
          . Të gjitha të drejtat e rezervuara.
        </p>
        <p className="mt-1">
          Zhvilluar me{" "}
          <span className="text-red-500 animate-pulse">❤️</span> nga Blerim Haxhiu dhe Kushtrim Zogaj për Prof.Dr Ekrem Halimi.
        </p>
      </footer>
    </div>
  );
}