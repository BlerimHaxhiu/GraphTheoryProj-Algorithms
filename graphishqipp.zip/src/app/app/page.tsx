
// @ts-nocheck
'use client';

import { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import { AppHeader } from '@/components/layout/AppHeader';
import { ControlsPanel } from '@/components/graph/ControlsPanel';
import { GraphCanvas } from '@/components/graph/GraphCanvas';
import { AlgorithmReportPanel } from '@/components/graph/AlgorithmReportPanel';
import { AdjacencyMatrixTable } from '@/components/graph/AdjacencyMatrixTable';
import { GraphStatsPanel } from '@/components/graph/GraphStatsPanel';
import { AlgorithmExplanationPanel } from '@/components/graph/AlgorithmExplanationPanel';
import { ExecutionHistoryPanel } from '@/components/graph/ExecutionHistoryPanel';
import { CompareAlgorithmsPanel } from '@/components/graph/CompareAlgorithmsPanel';
import { ExportPanel } from '@/components/graph/ExportPanel';

import type { Node, Edge, AlgorithmStep, AlgorithmType, SelectedToolType, ExecutionLogEntry, EdgeDrawType } from '@/types/graph';
import { generateNodeId, getNextNodeLabel, buildAdjacencyMatrix, generateEdgeId } from '@/lib/graph-utils';
import { dijkstra, bfs, dfs, aStar, bellmanFord, floydWarshall, kruskal, prim } from '@/lib/graph-algorithms';
import { useToast } from '@/hooks/use-toast';
import { Card } from '@/components/ui/card';
import { BrainCircuit } from 'lucide-react';


const CANVAS_PADDING = 20;
const NODE_RADIUS = 20;

function GrafiShqipPageContent() {
  const [nodes, setNodes] = useState<Node[]>([]);
  const [edges, setEdges] = useState<Edge[]>([]);
  const [isDirected, setIsDirected] = useState<boolean>(false);

  const [selectedTool, setSelectedTool] = useState<SelectedToolType>('pointer');
  const [currentAlgorithmStep, setCurrentAlgorithmStep] = useState<AlgorithmStep | null>(null);
  const [algorithmStepsQueue, setAlgorithmStepsQueue] = useState<AlgorithmStep[]>([]);
  const [stepIntervalId, setStepIntervalId] = useState<NodeJS.Timeout | null>(null);
  const [algorithmReportLog, setAlgorithmReportLog] = useState<AlgorithmStep[]>([]);
  const algorithmReportLogRef = useRef(algorithmReportLog);
  const [executionHistory, setExecutionHistory] = useState<ExecutionLogEntry[]>([]);
  const [edgeDrawType, setEdgeDrawType] = useState<EdgeDrawType>('straight');
  const [lastExecutedAlgorithm, setLastExecutedAlgorithm] = useState<AlgorithmType | null>(null);


  const { toast } = useToast();

  useEffect(() => {
    algorithmReportLogRef.current = algorithmReportLog;
  }, [algorithmReportLog]);

  useEffect(() => {
    const savedGraph = localStorage.getItem('grafiShqipGraph');
    if (savedGraph) {
      try {
        const { savedNodes, savedEdges, savedIsDirected } = JSON.parse(savedGraph);
        if (Array.isArray(savedNodes) && Array.isArray(savedEdges) && typeof savedIsDirected === 'boolean') {
          setNodes(savedNodes);
          setEdges(savedEdges);
          setIsDirected(savedIsDirected);
          toast({ title: 'Grafi u ngarkua', description: 'Grafi i ruajtur më parë u ngarkua nga memoria lokale.', variant: 'default' });
        }
      } catch (error) {
        console.error("Failed to load graph from localStorage", error);
        toast({ title: 'Gabim në ngarkim', description: 'Grafi i ruajtur nuk mund të ngarkohej.', variant: 'destructive' });
      }
    }
  }, [toast]);


  const [startNode, setStartNode] = useState<string | null>(null);
  const [endNode, setEndNode] = useState<string | null>(null);
  const [animationSpeed, setAnimationSpeed] = useState<number>(1000);

  const adjacencyMatrix = useMemo(() => {
    return buildAdjacencyMatrix(nodes, edges, isDirected);
  }, [nodes, edges, isDirected]);

  const svgRef = useRef<SVGSVGElement>(null);

  const handleAddNode = useCallback((clickX?: number, clickY?: number) => {
    const canvasWidth = svgRef.current?.viewBox.baseVal.width ?? 800;
    const canvasHeight = svgRef.current?.viewBox.baseVal.height ?? 600;

    let xPos: number;
    let yPos: number;

    if (clickX !== undefined && clickY !== undefined) {
      xPos = clickX;
      yPos = clickY;
    } else {
      if (nodes.length > 0) {
        const lastNode = nodes[nodes.length - 1];
        xPos = lastNode.x + NODE_RADIUS * 3 + (Math.random() * 40 - 20);
        yPos = lastNode.y + (Math.random() * 40 - 20);
      } else {
        xPos = canvasWidth / 2 + (Math.random() * 100 - 50);
        yPos = canvasHeight / 2 + (Math.random() * 100 - 50);
      }
    }

    xPos = Math.max(NODE_RADIUS + CANVAS_PADDING, Math.min(xPos, canvasWidth - NODE_RADIUS - CANVAS_PADDING));
    yPos = Math.max(NODE_RADIUS + CANVAS_PADDING, Math.min(yPos, canvasHeight - NODE_RADIUS - CANVAS_PADDING));

    const newNode: Node = {
      id: generateNodeId(),
      x: xPos,
      y: yPos,
      label: getNextNodeLabel(nodes),
    };
    setNodes(prevNodes => [...prevNodes, newNode]);
    toast({ title: 'Nyja u shtua', description: `Nyja ${newNode.label} u krijua.`, variant: 'default' });
  }, [nodes, svgRef, toast]);


  const handleDeleteNode = (nodeIdToDelete: string) => {
    const nodeToDelete = nodes.find(n => n.id === nodeIdToDelete);
    setNodes(prevNodes => prevNodes.filter(node => node.id !== nodeIdToDelete));
    setEdges(prevEdges => prevEdges.filter(edge => edge.source !== nodeIdToDelete && edge.target !== nodeIdToDelete));
    if (startNode === nodeIdToDelete) setStartNode(null);
    if (endNode === nodeIdToDelete) setEndNode(null);
    toast({ title: 'Nyja u fshi', description: `Nyja ${nodeToDelete?.label ?? nodeIdToDelete} dhe brinjët e lidhura u fshinë.`, variant: 'default' });
  };

  const handleToggleDirected = (checked: boolean) => {
    setIsDirected(checked);
  };

  const processAlgorithmStep = useCallback(() => {
    setAlgorithmStepsQueue(prevQueue => {
      if (prevQueue.length === 0) {
        if (stepIntervalId) {
          clearInterval(stepIntervalId);
          setStepIntervalId(null);
        }

        const completionMessageText = 'Algoritmi përfundoi.';
        const alreadyLoggedCompletion = algorithmReportLogRef.current.some(
          log => log.type === 'message' && log.message === completionMessageText
        );

        if (!alreadyLoggedCompletion) {
          const newCompletionStep = { id: `step-completion-${Date.now()}-${Math.random()}`, type: 'message' as const, message: completionMessageText };
          setAlgorithmReportLog(prevLog => {
            const lastEntryIsCompletion = prevLog.length > 0 &&
                                        prevLog[prevLog.length - 1].type === 'message' &&
                                        prevLog[prevLog.length - 1].message === completionMessageText;
            if (lastEntryIsCompletion) return prevLog;
            return [...prevLog, newCompletionStep];
          });
          setCurrentAlgorithmStep(newCompletionStep);
        } else {
           const lastStep = algorithmReportLogRef.current[algorithmReportLogRef.current.length -1];
           if(lastStep && lastStep.type === 'message' && lastStep.message === completionMessageText) {
             setCurrentAlgorithmStep(lastStep);
           } else {
             setCurrentAlgorithmStep(null);
           }
        }
        return [];
      }

      const [nextStepFromQueue, ...restOfQueue] = prevQueue;
       if (!nextStepFromQueue) return restOfQueue;

      const nextStep = { ...nextStepFromQueue, id: nextStepFromQueue.id || `step-runtime-${Date.now()}-${Math.random()}` };

      setCurrentAlgorithmStep(nextStep);

      setAlgorithmReportLog(prevLog => {
        const isDuplicate = prevLog.length > 0 && prevLog[prevLog.length - 1].id === nextStep.id && prevLog[prevLog.length - 1].type === nextStep.type;
        if (isDuplicate) {
          return prevLog;
        }
        return [...prevLog, nextStep];
      });
      return restOfQueue;
    });
  }, [stepIntervalId, animationSpeed]);

  const runAlgorithm = (algorithm: AlgorithmType, selectedStartNode?: string, selectedEndNode?: string) => {
    const opStartTime = performance.now();
    const entryStartTime = new Date();
    setLastExecutedAlgorithm(algorithm);


    if (stepIntervalId) {
      clearInterval(stepIntervalId);
      setStepIntervalId(null);
    }
    const initialResetStepId = `step-reset-${Date.now()}-${Math.random()}`;
    const initialMessageStepId = `step-initial-msg-${Date.now()}-${Math.random()}`;

    setCurrentAlgorithmStep({ type: 'reset', id: initialResetStepId, message: 'Përgatitja e algoritmit të ri...' });
    setAlgorithmReportLog([{ type: 'message', id: initialMessageStepId, message: `Fillimi i ${algorithm.toUpperCase()}...` }]);

    let steps: AlgorithmStep[] = [];
    const sNode = selectedStartNode || startNode;
    const eNode = selectedEndNode || endNode;
    const nodeMap = new Map(nodes.map(n => [n.id, n.label]));


    const algorithmNeedsStartNode = ['dijkstra', 'bfs', 'dfs', 'a-star', 'bellman-ford', 'prim'].includes(algorithm);
    const algorithmNeedsEndNode = ['dijkstra', 'a-star'].includes(algorithm);

    if (algorithmNeedsStartNode && !sNode) {
        const errorMsgId = `step-error-nostart-${Date.now()}-${Math.random()}`;
        toast({ title: "Gabim", description: "Ju lutem zgjidhni një nyje fillestare.", variant: "destructive" });
        setAlgorithmReportLog(prev => [...prev, {id: errorMsgId, type: 'message', message: "Gabim: Nyja fillestare nuk u zgjodh."}]);
        setCurrentAlgorithmStep({id: errorMsgId, type: 'message', message: "Gabim: Nyja fillestare nuk u zgjodh."});
        return;
    }
     if (algorithmNeedsEndNode && !eNode) {
        const errorMsgId = `step-error-noend-${algorithm}-${Date.now()}-${Math.random()}`;
        toast({ title: "Gabim", description: `Për ${algorithm.toUpperCase()}, zgjidhni nyjen përfundimtare.`, variant: "destructive" });
        setAlgorithmReportLog(prev => [...prev, {id: errorMsgId, type: 'message', message: `Gabim: Nyja përfundimtare nuk u zgjodh për ${algorithm.toUpperCase()}.`}]);
        setCurrentAlgorithmStep({id: errorMsgId, type: 'message', message: `Gabim: Nyja përfundimtare nuk u zgjodh për ${algorithm.toUpperCase()}.`});
        return;
    }


    switch (algorithm) {
      case 'dijkstra':
        steps = dijkstra(nodes, edges, isDirected, sNode!, eNode!);
        break;
      case 'bfs':
        steps = bfs(nodes, edges, isDirected, sNode!);
        break;
      case 'dfs':
        steps = dfs(nodes, edges, isDirected, sNode!);
        break;
      case 'a-star':
        steps = aStar(nodes, edges, isDirected, sNode!, eNode!);
        break;
      case 'bellman-ford':
        steps = bellmanFord(nodes, edges, isDirected, sNode!);
        break;
      case 'floyd-warshall':
        steps = floydWarshall(nodes, edges, isDirected);
        break;
      case 'kruskal':
        steps = kruskal(nodes, edges);
        break;
      case 'prim':
        steps = prim(nodes, edges, isDirected, sNode!);
        break;
      default:
        const exhaustiveCheck: never = algorithm;
        console.error(`Unknown algorithm: ${exhaustiveCheck}`);
        return;
    }

    const opEndTime = performance.now();
    const executionTimeMs = opEndTime - opStartTime;

    const validSteps = steps.filter(step => step && step.id);
    setAlgorithmStepsQueue(validSteps);

    let resultSummary = "Algoritmi përfundoi.";
    if (validSteps.length > 0) {
        const lastStep = validSteps[validSteps.length - 1];
        if (lastStep.type === 'message') {
            resultSummary = lastStep.message || resultSummary;
        } else if (lastStep.type === 'highlight-path' && lastStep.path) {
             resultSummary = `Rruga: ${lastStep.path.map(id => nodeMap.get(id) || id).join(' → ')}`;
        }
    } else {
        resultSummary = 'Algoritmi nuk prodhoi hapa.';
    }

    setExecutionHistory(prevHistory => [
      ...prevHistory,
      {
        id: `exec-${Date.now()}`,
        algorithm,
        startTime: entryStartTime,
        endTime: new Date(),
        executionTimeMs: executionTimeMs,
        nodesCountSnapshot: nodes.length,
        edgesCountSnapshot: edges.length,
        startNodeLabel: sNode ? nodeMap.get(sNode) : undefined,
        endNodeLabel: eNode ? nodeMap.get(eNode) : undefined,
        resultSummary,
      }
    ]);


    if (validSteps.length > 0) {
        processAlgorithmStep();
        const newIntervalId = setInterval(processAlgorithmStep, animationSpeed);
        setStepIntervalId(newIntervalId);
    } else {
        const noStepsMsgId = `step-nosteps-${Date.now()}-${Math.random()}`;
        const noStepsMessage = 'Algoritmi nuk prodhoi hapa (p.sh., grafi bosh ose rruga nuk ekziston).';
        setCurrentAlgorithmStep({ type: 'message', id: noStepsMsgId, message: noStepsMessage });
        setAlgorithmReportLog(prev => [...prev, { type: 'message', id: noStepsMsgId, message: noStepsMessage}]);
    }
  };

  useEffect(() => {
    return () => {
      if (stepIntervalId) clearInterval(stepIntervalId);
    };
  }, [stepIntervalId]);


  const handleClearGraph = useCallback(() => {
    if (stepIntervalId) {
        clearInterval(stepIntervalId);
        setStepIntervalId(null);
    }
    setNodes([]);
    setEdges([]);
    setCurrentAlgorithmStep(null);
    setAlgorithmStepsQueue([]);
    setAlgorithmReportLog([]);
    setStartNode(null);
    setEndNode(null);
    setLastExecutedAlgorithm(null);
    toast({ title: 'Grafi u pastrua', description: 'Të gjitha nyjet dhe brinjët janë hequr.', variant: 'default' });
  }, [stepIntervalId, toast]);

  const handleDrawSuggestedGraph = useCallback((suggestionType: string, customData?: { nodeCount?: number; graphType?: string }) => {
    handleClearGraph();

    const canvasWidth = svgRef.current?.viewBox.baseVal.width ?? 800;
    const canvasHeight = svgRef.current?.viewBox.baseVal.height ?? 600;
    const centerX = canvasWidth / 2;
    const centerY = canvasHeight / 2;
    let radius = Math.min(canvasWidth, canvasHeight) / 3.5;

    let newNodes: Node[] = [];
    let newEdges: Edge[] = [];
    const n = customData?.nodeCount || 5; 

    let finalGraphType = suggestionType;
    let toastMessageTitle = 'Grafi u Vizatua';
    let toastMessageDescription = '';

    if (suggestionType === 'custom-graph' && customData?.graphType) {
        finalGraphType = customData.graphType;
    }

    if (finalGraphType !== 'custom-graph' && (n <= 0 || n > 50) && suggestionType.startsWith('custom-')) { 
        toast({ title: 'Gabim', description: 'Numri i nyjeve duhet të jetë midis 1 dhe 50.', variant: 'destructive'});
        return;
    }


    switch (finalGraphType) {
      case 'complete-k4': 
      case 'complete': {
        const count = finalGraphType === 'complete-k4' ? 4 : n;
        if (count > 15) radius *= 1.5; 
        else if (count > 10) radius *= 1.2;


        for (let i = 0; i < count; i++) {
          newNodes.push({
            id: generateNodeId(),
            x: centerX + radius * Math.cos(2 * Math.PI * i / count - Math.PI / 2),
            y: centerY + radius * Math.sin(2 * Math.PI * i / count - Math.PI / 2),
            label: getNextNodeLabel(newNodes),
          });
        }
        for (let i = 0; i < count; i++) {
          for (let j = i + 1; j < count; j++) {
            newEdges.push({
              id: generateEdgeId(),
              source: newNodes[i].id,
              target: newNodes[j].id,
              weight: 1,
            });
          }
        }
        toastMessageDescription = finalGraphType === 'complete-k4' ? 'Grafi i Plotë K4 u krijua.' : `Grafi i Plotë K${count} u krijua.`;
        break;
      }
      case 'star-s5': 
      case 'star': {
        const numPeripheral = finalGraphType === 'star-s5' ? 4 : n - 1;
        if (numPeripheral < 0) { 
             if (n === 1) { 
                newNodes.push({ id: generateNodeId(), x: centerX, y: centerY, label: getNextNodeLabel([]) });
             }
             toastMessageDescription = `Graf me ${n} nyje u krijua.`;
             break;
        }

        const centerNode: Node = {
          id: generateNodeId(),
          x: centerX,
          y: centerY,
          label: getNextNodeLabel([]),
        };
        newNodes.push(centerNode);

        for (let i = 0; i < numPeripheral; i++) {
          const peripheralNode: Node = {
            id: generateNodeId(),
            x: centerX + radius * Math.cos(2 * Math.PI * i / numPeripheral),
            y: centerY + radius * Math.sin(2 * Math.PI * i / numPeripheral),
            label: getNextNodeLabel(newNodes),
          };
          newNodes.push(peripheralNode);
          newEdges.push({
            id: generateEdgeId(),
            source: centerNode.id,
            target: peripheralNode.id,
            weight: 1,
          });
        }
        toastMessageDescription = finalGraphType === 'star-s5' ? 'Grafi Yll S5 u krijua.' : `Grafi Yll S${n} u krijua.`;
        break;
      }
      case 'cycle-c5': 
      case 'cycle': {
        const count = finalGraphType === 'cycle-c5' ? 5 : n;
        if (count < 1) {
             toastMessageDescription = 'Nuk mund të krijohet cikël me më pak se 1 nyje.';
             break;
        }
        if (count === 1) { 
            newNodes.push({ id: generateNodeId(), x: centerX, y: centerY, label: getNextNodeLabel([]) });
            toastMessageDescription = 'Graf me 1 nyje (pa cikle) u krijua.';
            break;
        }
         if (count === 2) { 
            newNodes.push({ id: generateNodeId(), x: centerX - radius/3, y: centerY, label: getNextNodeLabel(newNodes) });
            newNodes.push({ id: generateNodeId(), x: centerX + radius/3, y: centerY, label: getNextNodeLabel(newNodes) });
            newEdges.push({ id: generateEdgeId(), source: newNodes[0].id, target: newNodes[1].id, weight: 1 });
            if (!isDirected) { 
                // For undirected C2, you might want two edges or just one.
                // Standard definition of C2 often means two nodes and two edges between them if undirected.
                // If it means just a path of length 1, then one edge is fine.
                // Here we'll assume one edge represents the connection.
            }
            toastMessageDescription = `Graf Ciklik C${count} u krijua.`;
            break;
        }


        for (let i = 0; i < count; i++) {
          newNodes.push({
            id: generateNodeId(),
            x: centerX + radius * Math.cos(2 * Math.PI * i / count - Math.PI / 2),
            y: centerY + radius * Math.sin(2 * Math.PI * i / count - Math.PI / 2),
            label: getNextNodeLabel(newNodes),
          });
        }
        for (let i = 0; i < count; i++) {
          newEdges.push({
            id: generateEdgeId(),
            source: newNodes[i].id,
            target: newNodes[(i + 1) % count].id,
            weight: 1,
          });
        }
        toastMessageDescription = finalGraphType === 'cycle-c5' ? 'Grafi Ciklik C5 u krijua.' : `Grafi Ciklik C${count} u krijua.`;
        break;
      }
      case 'simple-tree': 
      case 'tree': { 
        const count = finalGraphType === 'simple-tree' ? 7 : n;
        if (finalGraphType === 'simple-tree') {
            const nodePositions = [
              { x: centerX, y: centerY - radius * 0.6 }, 
              { x: centerX - radius * 0.5, y: centerY }, 
              { x: centerX + radius * 0.5, y: centerY }, 
              { x: centerX - radius * 0.75, y: centerY + radius * 0.6 }, 
              { x: centerX - radius * 0.25, y: centerY + radius * 0.6 }, 
              { x: centerX + radius * 0.25, y: centerY + radius * 0.6 }, 
              { x: centerX + radius * 0.75, y: centerY + radius * 0.6 }, 
            ];
            for(let i=0; i < count; i++) {
              newNodes.push({
                id: generateNodeId(),
                x: nodePositions[i].x,
                y: nodePositions[i].y,
                label: getNextNodeLabel(newNodes)
              });
            }
            const treeEdgesDefinition = [
              { sourceIdx: 0, targetIdx: 1 }, { sourceIdx: 0, targetIdx: 2 },
              { sourceIdx: 1, targetIdx: 3 }, { sourceIdx: 1, targetIdx: 4 },
              { sourceIdx: 2, targetIdx: 5 }, { sourceIdx: 2, targetIdx: 6 },
            ];
            treeEdgesDefinition.forEach(def => {
              newEdges.push({
                id: generateEdgeId(),
                source: newNodes[def.sourceIdx].id,
                target: newNodes[def.targetIdx].id,
                weight: 1,
              });
            });
            toastMessageDescription = 'Graf Pemë e Thjeshtë Fikse u krijua.';
        } else { // finalGraphType === 'tree' (custom N)
             if (count <= 0) {
                 toastMessageDescription = 'Numri i nyjeve duhet të jetë pozitiv.';
                 break;
             }
             if (count === 1) {
                newNodes.push({ id: generateNodeId(), x: centerX, y: centerY, label: getNextNodeLabel([]) });
                toastMessageDescription = `Graf Pemë me 1 Nyje u krijua.`;
                break;
             }

            // Generate all nodes first
            for (let i = 0; i < count; i++) {
                newNodes.push({
                    id: generateNodeId(),
                    x: 0, // Temporary, will be set by layout
                    y: 0, // Temporary
                    label: getNextNodeLabel(newNodes)
                });
            }

            // Create edges for a binary-like tree structure
            // Node i is connected to parent Math.floor((i-1)/2)
            for (let i = 1; i < count; i++) {
                const parentIndex = Math.floor((i - 1) / 2);
                if (parentIndex >= 0 && parentIndex < i) {
                    newEdges.push({
                        id: generateEdgeId(),
                        source: newNodes[parentIndex].id,
                        target: newNodes[i].id,
                        weight: 1
                    });
                }
            }
            
            // Position nodes in a tree-like layout using BFS to determine levels
            const nodeLevels: string[][] = [];
            const positionedNodes = new Set<string>();

            if (newNodes.length > 0) {
                const q: { nodeId: string; depth: number }[] = [{ nodeId: newNodes[0].id, depth: 0 }];
                const visitedLayout = new Set<string>();
                visitedLayout.add(newNodes[0].id);
                
                let head = 0;
                while(head < q.length) {
                    const { nodeId: u, depth: d } = q[head++];
                    if (!nodeLevels[d]) nodeLevels[d] = [];
                    nodeLevels[d].push(u);

                    const children = newEdges
                        .filter(edge => edge.source === u && !visitedLayout.has(edge.target))
                        .map(edge => edge.target);
                    
                    for (const v of children) {
                        if (!visitedLayout.has(v)) {
                            visitedLayout.add(v);
                            q.push({ nodeId: v, depth: d + 1 });
                        }
                    }
                }
            }
            
            const ySpacing = Math.max(80, (canvasHeight - 2 * CANVAS_PADDING - 2 * NODE_RADIUS) / Math.max(1, nodeLevels.length));
            const baseYSvg = CANVAS_PADDING + NODE_RADIUS + (nodeLevels.length === 1 ? (canvasHeight/2 - (CANVAS_PADDING + NODE_RADIUS)) : 30) ;

            nodeLevels.forEach((level, depth) => {
                const levelWidth = canvasWidth - 2 * CANVAS_PADDING - 2 * NODE_RADIUS;
                const xSpacing = levelWidth / (level.length + 1);
                level.forEach((nodeId, indexInLevel) => {
                    const nodeToUpdate = newNodes.find(n => n.id === nodeId);
                    if (nodeToUpdate) {
                        nodeToUpdate.x = CANVAS_PADDING + NODE_RADIUS + xSpacing * (indexInLevel + 1);
                        nodeToUpdate.y = baseYSvg + depth * ySpacing;
                        
                        nodeToUpdate.x = Math.max(NODE_RADIUS + CANVAS_PADDING, Math.min(nodeToUpdate.x, canvasWidth - NODE_RADIUS - CANVAS_PADDING));
                        nodeToUpdate.y = Math.max(NODE_RADIUS + CANVAS_PADDING, Math.min(nodeToUpdate.y, canvasHeight - NODE_RADIUS - CANVAS_PADDING));
                        positionedNodes.add(nodeId);
                    }
                });
            });
            
            // Position any unpositioned nodes (e.g. if graph was disconnected, though tree logic shouldn't cause this)
            newNodes.forEach(node => {
                if (!positionedNodes.has(node.id)) {
                    node.x = centerX + (Math.random() * radius - radius / 2);
                    node.y = centerY + (Math.random() * radius - radius / 2);
                }
            });
            toastMessageDescription = `Graf Pemë me ${count} Nyje u krijua.`;
        }
        break;
      }
      case 'path': {
        if (n <= 0) {toastMessageDescription = 'Numri i nyjeve duhet të jetë pozitiv.'; break;}
        const spacing = (canvasWidth - 2 * CANVAS_PADDING - 2 * NODE_RADIUS) / Math.max(1, n -1);
        for (let i = 0; i < n; i++) {
          newNodes.push({
            id: generateNodeId(),
            x: CANVAS_PADDING + NODE_RADIUS + i * spacing,
            y: centerY,
            label: getNextNodeLabel(newNodes),
          });
        }
        if (n > 1) { 
            for (let i = 0; i < n - 1; i++) {
              newEdges.push({
                id: generateEdgeId(),
                source: newNodes[i].id,
                target: newNodes[i + 1].id,
                weight: 1,
              });
            }
        }
        toastMessageDescription = `Graf Rrugë me ${n} Nyje u krijua.`;
        break;
      }
      default:
        toastMessageTitle = 'Lloj i Panjohur';
        toastMessageDescription = `Sugjerimi '${suggestionType}' ose lloji '${customData?.graphType}' nuk njihet.`;
        return;
    }
    setNodes(newNodes);
    setEdges(newEdges);
    if(toastMessageDescription) {
        toast({ title: toastMessageTitle, description: toastMessageDescription, variant: 'default' });
    }
  }, [handleClearGraph, svgRef, toast, isDirected]); 

  const handleSaveGraph = () => {
    try {
      const graphToSave = JSON.stringify({ savedNodes: nodes, savedEdges: edges, savedIsDirected: isDirected });
      localStorage.setItem('grafiShqipGraph', graphToSave);
      toast({ title: 'Grafi u Ruajt', description: 'Grafi aktual u ruajt në memorien lokale të shfletuesit.', variant: 'default' });
    } catch (error) {
      console.error("Failed to save graph to localStorage", error);
      toast({ title: 'Gabim në Ruajtje', description: 'Grafi nuk mund të ruhej.', variant: 'destructive' });
    }
  };

  const handleExportJSON = () => {
    const graphJSON = JSON.stringify({ nodes, edges, isDirected }, null, 2);
    const blob = new Blob([graphJSON], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'grafi.json';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    toast({ title: 'Eksportuar si JSON', description: 'Grafi u shkarkua si skedar JSON.', variant: 'default' });
  };

  const getThemeCssVariables = () => {
    if (typeof window === 'undefined') return '';
    const rootStyle = getComputedStyle(document.documentElement);
    const variables = [
      '--background', '--foreground', '--card', '--card-foreground',
      '--popover', '--popover-foreground', '--primary', '--primary-foreground',
      '--secondary', '--secondary-foreground', '--muted', '--muted-foreground',
      '--accent', '--accent-foreground', '--destructive', '--destructive-foreground',
      '--border', '--input', '--ring', '--font-geist-sans'
    ];
    let cssText = ':root {\n';
    variables.forEach(variable => {
      const value = rootStyle.getPropertyValue(variable).trim();
      if (value) {
        cssText += `  ${variable}: ${value};\n`;
      }
    });
    if (!rootStyle.getPropertyValue('--font-geist-sans').trim()) {
        const bodyFont = getComputedStyle(document.body).fontFamily;
        if (bodyFont) {
            cssText += `  --font-geist-sans: ${bodyFont};\n`;
        }
    }
    cssText += '}';
    return cssText;
  };

  const handleExportPNG = () => {
    const svgElement = svgRef.current;
    if (svgElement) {
      const svgClone = svgElement.cloneNode(true) as SVGSVGElement;
      
      const styleElement = document.createElementNS("http://www.w3.org/2000/svg", "style");
      styleElement.textContent = getThemeCssVariables();
      svgClone.prepend(styleElement);

      const elementsToStyle = svgClone.querySelectorAll('circle, path, text, rect'); 
      elementsToStyle.forEach(el => {
        const originalEl = svgElement.querySelector(`[id="${el.id}"]`) || svgElement.querySelector(el.tagName + (el.getAttribute('d') ? `[d="${el.getAttribute('d')}"]` : '')); 
        if (originalEl) {
          const computedStyle = getComputedStyle(originalEl);
          if (!el.getAttribute('fill') && computedStyle.fill && computedStyle.fill !== 'rgb(0, 0, 0)') { 
            el.setAttribute('fill', computedStyle.fill);
          }
          if (!el.getAttribute('stroke') && computedStyle.stroke && computedStyle.stroke !== 'none') {
            el.setAttribute('stroke', computedStyle.stroke);
          }
          if (!el.getAttribute('stroke-width') && computedStyle.strokeWidth) {
            el.setAttribute('stroke-width', computedStyle.strokeWidth);
          }
           if (el.tagName === 'text') {
                if (!el.getAttribute('font-family') && computedStyle.fontFamily) {
                    el.setAttribute('font-family', computedStyle.fontFamily);
                }
                if (!el.getAttribute('font-size') && computedStyle.fontSize) {
                    el.setAttribute('font-size', computedStyle.fontSize);
                }
                if (!el.getAttribute('font-weight') && computedStyle.fontWeight) {
                    el.setAttribute('font-weight', computedStyle.fontWeight);
                }
                if (!el.getAttribute('fill') && computedStyle.color && computedStyle.color !== 'rgb(0, 0, 0)') { 
                     el.setAttribute('fill', computedStyle.color);
                }
           }
        }
      });


      const svgData = new XMLSerializer().serializeToString(svgClone);
      const canvas = document.createElement('canvas');

      const { width: svgNativeWidth, height: svgNativeHeight } = svgElement.viewBox.baseVal;
      const scaleFactor = 2; 
      canvas.width = svgNativeWidth * scaleFactor;
      canvas.height = svgNativeHeight * scaleFactor;

      const ctx = canvas.getContext('2d');
      if (ctx) {
        const img = new Image();
        img.onload = () => {
          const bgColor = getComputedStyle(document.documentElement).getPropertyValue('--card').trim() || 'hsl(0 0% 100%)';
          ctx.fillStyle = bgColor;
          ctx.fillRect(0, 0, canvas.width, canvas.height);
          ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
          const pngFile = canvas.toDataURL('image/png');
          const downloadLink = document.createElement('a');
          downloadLink.download = 'grafi.png';
          downloadLink.href = pngFile;
          document.body.appendChild(downloadLink); 
          downloadLink.click();
          document.body.removeChild(downloadLink);
          toast({ title: 'Eksportuar si PNG', description: 'Grafi u shkarkua si skedar PNG.', variant: 'default' });
        };
        img.onerror = () => {
          toast({ title: 'Gabim Eksporti PNG', description: 'Imazhi SVG nuk mund të ngarkohej.', variant: 'destructive'});
        }
        img.src = 'data:image/svg+xml;base64,' + btoa(unescape(encodeURIComponent(svgData)));
      } else {
         toast({ title: 'Gabim Eksporti PNG', description: 'Konteksti i kanavacës nuk mund të krijohej.', variant: 'destructive'});
      }
    } else {
       toast({ title: 'Gabim Eksporti PNG', description: 'Elementi SVG nuk u gjet.', variant: 'destructive'});
    }
  };

  const handleGenerateFromMatrix = useCallback((matrixString: string) => {
    handleClearGraph();
    try {
        const rows = matrixString.trim().split('\n');
        const numericMatrix = rows.map(row => 
            row.trim().split(/[\s,]+/).map(val => {
                const num = parseFloat(val);
                return isNaN(num) ? (val.toLowerCase() === 'inf' || val.toLowerCase() === 'infinity' ? Infinity : NaN) : num;
            })
        );

        const n = numericMatrix.length;
        if (n === 0 || numericMatrix.some(row => row.length !== n || row.some(isNaN))) {
            toast({ title: "Matricë e Pavlefshme", description: "Matrica duhet të jetë katrore dhe të përmbajë vetëm numra ose 'Inf'.", variant: "destructive" });
            return;
        }

        const canvasWidth = svgRef.current?.viewBox.baseVal.width ?? 800;
        const canvasHeight = svgRef.current?.viewBox.baseVal.height ?? 600;
        const centerX = canvasWidth / 2;
        const centerY = canvasHeight / 2;
        const radius = Math.min(canvasWidth, canvasHeight) / 3;

        const newNodes: Node[] = [];
        for (let i = 0; i < n; i++) {
            newNodes.push({
                id: generateNodeId(),
                label: getNextNodeLabel(newNodes),
                x: centerX + radius * Math.cos(2 * Math.PI * i / n - Math.PI / 2),
                y: centerY + radius * Math.sin(2 * Math.PI * i / n - Math.PI / 2),
            });
        }

        const newEdges: Edge[] = [];
        for (let i = 0; i < n; i++) {
            for (let j = 0; j < n; j++) {
                if (numericMatrix[i][j] !== 0 && numericMatrix[i][j] !== Infinity) {
                    if (!isDirected && i > j && numericMatrix[j]?.[i] === numericMatrix[i]?.[j]) continue; 
                     if (isDirected || i !== j || (i === j && numericMatrix[i][j] !== 0) ) { 
                        newEdges.push({
                            id: generateEdgeId(),
                            source: newNodes[i].id,
                            target: newNodes[j].id,
                            weight: numericMatrix[i][j],
                        });
                    }
                }
            }
        }
        setNodes(newNodes);
        setEdges(newEdges);
        toast({ title: "Grafi u Gjenerua", description: "Grafi u krijua nga matrica e fqinjësisë.", variant: "default" });
    } catch (error) {
        console.error("Error generating graph from matrix:", error);
        toast({ title: "Gabim në Gjenerim", description: "Ndodhi një gabim gjatë përpunimit të matricës.", variant: "destructive" });
    }
  }, [handleClearGraph, svgRef, toast, isDirected]);

  const handleGenerateFromJSON = useCallback((jsonString: string) => {
    handleClearGraph();
    try {
        const parsedData = JSON.parse(jsonString);
        if (
            !parsedData ||
            typeof parsedData !== 'object' ||
            !Array.isArray(parsedData.nodes) ||
            !Array.isArray(parsedData.edges) ||
            (parsedData.isDirected !== undefined && typeof parsedData.isDirected !== 'boolean')
        ) {
            toast({ title: "JSON i Pavlefshëm", description: "Struktura e JSON nuk është e saktë. Duhet të përmbajë 'nodes', 'edges', dhe opsionalisht 'isDirected'.", variant: "destructive" });
            return;
        }

        const validNodes = parsedData.nodes.every(n => n.id && n.label && typeof n.x === 'number' && typeof n.y === 'number');
        const validEdges = parsedData.edges.every(e => e.id && e.source && e.target && typeof e.weight === 'number');

        if (!validNodes || !validEdges) {
            toast({ title: "Strukturë e Pavlefshme e Nyjeve/Brinjëve", description: "Nyjet duhet të kenë id, label, x, y. Brinjët duhet të kenë id, source, target, weight.", variant: "destructive" });
            return;
        }
        
        setNodes(parsedData.nodes as Node[]);
        setEdges(parsedData.edges as Edge[]);
        if (parsedData.isDirected !== undefined) {
            setIsDirected(parsedData.isDirected as boolean);
        }
        toast({ title: "Grafi u Gjenerua", description: "Grafi u krijua nga skripta JSON.", variant: "default" });

    } catch (error) {
        console.error("Error generating graph from JSON:", error);
        toast({ title: "Gabim në Përpunimin e JSON", description: "Skripta JSON nuk mund të përpunohej. Sigurohuni që formati është i saktë.", variant: "destructive" });
    }
  }, [handleClearGraph, toast]);


  return (
     <div className="flex flex-col h-screen text-foreground bg-background overflow-hidden">
      <AppHeader />
      <div className="grid grid-cols-1 md:grid-cols-[minmax(320px,380px)_1fr] gap-4 p-4 flex-1 overflow-hidden">
        <aside className="w-full md:w-auto flex flex-col gap-4 overflow-y-auto print:hidden h-full p-1 custom-scrollbar">
            <ControlsPanel
              nodes={nodes}
              edges={edges}
              isDirected={isDirected}
              onAddNode={handleAddNode}
              onToggleDirected={handleToggleDirected}
              onRunAlgorithm={runAlgorithm}
              onClearGraph={handleClearGraph}
              selectedTool={selectedTool}
              setSelectedTool={setSelectedTool}
              startNode={startNode}
              setStartNode={setStartNode}
              endNode={endNode}
              setEndNode={setEndNode}
              animationSpeed={animationSpeed}
              onAnimationSpeedChange={setAnimationSpeed}
              onDrawSuggestedGraph={handleDrawSuggestedGraph}
              edgeDrawType={edgeDrawType}
              setEdgeDrawType={setEdgeDrawType}
              onGenerateFromMatrix={handleGenerateFromMatrix}
              onGenerateFromJSON={handleGenerateFromJSON}
            />
        </aside>

        <main className="flex-1 flex flex-col gap-4 overflow-y-auto h-full custom-scrollbar"> 
           <Card className="flex-grow-[2] flex-shrink basis-0 flex flex-col min-h-[350px] sm:min-h-[400px] md:min-h-[450px] shadow-lg overflow-hidden rounded-xl border">
              <GraphCanvas
                svgRef={svgRef}
                nodes={nodes}
                edges={edges}
                isDirected={isDirected}
                onNodesChange={setNodes}
                onEdgesChange={setEdges}
                selectedTool={selectedTool}
                setSelectedTool={setSelectedTool}
                currentAlgorithmStep={currentAlgorithmStep}
                startNode={startNode}
                endNode={endNode}
                setStartNode={setStartNode}
                setEndNode={setEndNode}
                onDeleteNode={handleDeleteNode}
                onAddNode={handleAddNode}
                edgeDrawType={edgeDrawType}
              />
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 min-h-[250px] flex-grow-[1] flex-shrink basis-0 print:hidden">
            <AdjacencyMatrixTable
              matrix={adjacencyMatrix}
              nodes={nodes}
              currentAlgorithmStep={currentAlgorithmStep}
            />
            <AlgorithmReportPanel
              reportLog={algorithmReportLog}
              nodes={nodes}
              edges={edges}
            />
          </div>

          <div className="mt-2 grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4 pb-4 print:hidden">
            <GraphStatsPanel nodes={nodes} edges={edges} isDirected={isDirected} />
            <ExecutionHistoryPanel history={executionHistory} />
            <ExportPanel
              onSaveGraph={handleSaveGraph}
              onExportJSON={handleExportJSON}
              onExportPNG={handleExportPNG}
            />
            <AlgorithmExplanationPanel algorithm={lastExecutedAlgorithm} />
            <div className="md:col-span-2 xl:col-span-2">
              <CompareAlgorithmsPanel history={executionHistory} nodes={nodes} edges={edges} isDirected={isDirected} />
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}

export default function GrafiShqipAppPage() {
  const [isClient, setIsClient] = useState(false);
  useEffect(() => {
    setIsClient(true);
  }, []);

  if (!isClient) {
    return (
      <div className="flex flex-col h-screen text-foreground overflow-hidden bg-background">
        <AppHeader />
        <div className="flex items-center justify-center flex-1 p-4">
          <div className="flex flex-col items-center text-muted-foreground">
            <BrainCircuit className="w-16 h-16 mb-4 animate-pulse" />
            <p className="text-xl">Duke ngarkuar aplikacionin...</p>
            <p className="text-sm">Ju lutem prisni pak.</p>
          </div>
        </div>
      </div>
    );
  }
  return <GrafiShqipPageContent />;
}

