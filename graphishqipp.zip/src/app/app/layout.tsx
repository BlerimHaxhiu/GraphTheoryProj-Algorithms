import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Aplikacion për Analizën e Algoritmeve të Grafeve',
  description: 'Krijo, modifiko, dhe studio grafet. Përdor algoritmet Dijkstra, BFS, DFS dhe merr rekomandime nga AI për grafikun tënd.',
};

export default function AppLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    // This div will expand to fill the <main> from RootLayout.
    // It's a flex container for its children (e.g., the page content with sidebar).
    <div className="flex-1 flex flex-col">
      {children}
    </div>
  );
}
