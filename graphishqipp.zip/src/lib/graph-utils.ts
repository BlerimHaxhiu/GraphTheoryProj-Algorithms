
import type { Node, Edge, AdjacencyMatrix, GraphData } from '@/types/graph';

export interface GraphStats {
  nodesCount: number;
  edgesCount: number;
  density: number | string; // Can be 'N/A'
  connectedComponents: number;
  isComplete: boolean;
}

export interface DegreeDistribution {
  degree: number;
  count: number;
}

export function buildAdjacencyMatrix(nodes: Node[], edges: Edge[], isDirected: boolean): AdjacencyMatrix {
  const matrix: AdjacencyMatrix = Array(nodes.length)
    .fill(null)
    .map(() => Array(nodes.length).fill(Infinity));

  const nodeIndexMap = new Map(nodes.map((node, i) => [node.id, i]));

  for (let i = 0; i < nodes.length; i++) {
    matrix[i][i] = 0;
  }

  edges.forEach(edge => {
    const sourceIndex = nodeIndexMap.get(edge.source);
    const targetIndex = nodeIndexMap.get(edge.target);

    if (sourceIndex !== undefined && targetIndex !== undefined) {
      matrix[sourceIndex][targetIndex] = edge.weight;
      if (!isDirected && sourceIndex !== targetIndex) {
        matrix[targetIndex][sourceIndex] = edge.weight;
      }
    }
  });

  return matrix;
}

export function getGraphRepresentationForAI(
  nodes: Node[],
  edges: Edge[],
  isDirected: boolean,
  startNodeId?: string | null,
  endNodeId?: string | null
): GraphData {
  const matrix = buildAdjacencyMatrix(nodes, edges, isDirected);
  const nodeMap = new Map(nodes.map(n => [n.id, n.label]));

  return {
    graphRepresentation: JSON.stringify(matrix),
    isDirected,
    nodesCount: nodes.length,
    nodeLabels: nodes.map(n => n.label),
    startNodeLabel: startNodeId ? nodeMap.get(startNodeId) : undefined,
    endNodeLabel: endNodeId ? nodeMap.get(endNodeId) : undefined,
  };
}


export function generateNodeId(): string {
  return `node-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`;
}

export function generateEdgeId(): string {
  return `edge-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`;
}

export function getNextNodeLabel(existingNodes: Node[]): string {
  const existingLabels = new Set(existingNodes.map(n => n.label));
  let charCodeA = 'A'.charCodeAt(0);
  let label = '';
  let count = 0;

  while (true) {
    let tempLabel = '';
    let num = count;
    do {
      tempLabel = String.fromCharCode(charCodeA + (num % 26)) + tempLabel;
      num = Math.floor(num / 26) -1; 
    } while (num >=0);
    
    label = tempLabel;
    if (!existingLabels.has(label)) {
      return label;
    }
    count++;
  }
}

function getConnectedComponents(nodes: Node[], edges: Edge[], isDirected: boolean): number {
  if (nodes.length === 0) return 0;

  const adj = new Map<string, string[]>();
  nodes.forEach(node => adj.set(node.id, []));
  edges.forEach(edge => {
    adj.get(edge.source)!.push(edge.target);
    if (!isDirected) {
      adj.get(edge.target)!.push(edge.source);
    }
  });

  const visited = new Set<string>();
  let components = 0;

  function dfs(nodeId: string) {
    visited.add(nodeId);
    (adj.get(nodeId) || []).forEach(neighbor => {
      if (!visited.has(neighbor)) {
        dfs(neighbor);
      }
    });
  }

  nodes.forEach(node => {
    if (!visited.has(node.id)) {
      dfs(node.id);
      components++;
    }
  });
  return components;
}

export function calculateGraphStats(nodes: Node[], edges: Edge[], isDirected: boolean): GraphStats {
  const V = nodes.length;
  const E = edges.length;
  let density: number | string;
  let isComplete = false;

  if (V < 2) {
    density = V === 0 ? 0 : 'N/A';
    isComplete = V === 1 || V === 0; // A single node or no nodes can be considered "complete" vacuously
  } else {
    if (isDirected) {
      density = E / (V * (V - 1));
      // For a directed graph to be complete (tournament or stronger definition), all V*(V-1) edges must exist.
      isComplete = E === V * (V - 1);
    } else {
      density = (2 * E) / (V * (V - 1));
      // For an undirected graph to be complete, it must have V*(V-1)/2 edges.
      isComplete = E === (V * (V - 1)) / 2;
    }
    density = parseFloat(density.toFixed(3));
  }
  
  const connectedComponents = getConnectedComponents(nodes, edges, isDirected);

  return {
    nodesCount: V,
    edgesCount: E,
    density,
    connectedComponents,
    isComplete,
  };
}

export function calculateDegreeDistribution(nodes: Node[], edges: Edge[], isDirected: boolean): DegreeDistribution[] {
  if (nodes.length === 0) return [];

  const degrees = new Map<string, number>();
  nodes.forEach(node => degrees.set(node.id, 0));

  edges.forEach(edge => {
    if (isDirected) {
      degrees.set(edge.source, (degrees.get(edge.source) || 0) + 1); // Out-degree
      // If you need in-degree as well, you'd count edge.target occurrences.
      // For simplicity, we'll consider out-degree for directed graphs here.
      // Or total degree: degrees.set(edge.target, (degrees.get(edge.target) || 0) + 1);
    } else {
      degrees.set(edge.source, (degrees.get(edge.source) || 0) + 1);
      if (edge.source !== edge.target) { // Avoid double counting for self-loops
         degrees.set(edge.target, (degrees.get(edge.target) || 0) + 1);
      }
    }
  });

  const distributionMap = new Map<number, number>();
  degrees.forEach(degree => {
    distributionMap.set(degree, (distributionMap.get(degree) || 0) + 1);
  });

  return Array.from(distributionMap.entries())
    .map(([degree, count]) => ({ degree, count }))
    .sort((a, b) => a.degree - b.degree);
}
