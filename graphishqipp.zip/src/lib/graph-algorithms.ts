import type { Node, Edge, AlgorithmStep } from '@/types/graph';

const INFINITY = Number.MAX_SAFE_INTEGER;
let stepCounterGlobal = 0; 

const generateStepId = () => `alg-step-${Date.now()}-${stepCounterGlobal++}`;

// Helper: Euclidean distance for A*
function heuristic(nodeA: Node, nodeB: Node): number {
  if (!nodeA || !nodeB) return INFINITY; // Return INFINITY if nodes are undefined to penalize such paths
  return Math.sqrt(Math.pow(nodeA.x - nodeB.x, 2) + Math.pow(nodeA.y - nodeB.y, 2));
}

// Helper: DSU for Kruskal
class DSU {
  parent: Map<string, string>;
  constructor(nodes: Node[]) {
    this.parent = new Map();
    nodes.forEach(node => this.parent.set(node.id, node.id));
  }

  find(nodeId: string): string {
    if (this.parent.get(nodeId) === nodeId) {
      return nodeId;
    }
    const root = this.find(this.parent.get(nodeId)!);
    this.parent.set(nodeId, root);
    return root;
  }

  union(nodeIdA: string, nodeIdB: string): boolean {
    const rootA = this.find(nodeIdA);
    const rootB = this.find(nodeIdB);
    if (rootA !== rootB) {
      this.parent.set(rootB, rootA);
      return true;
    }
    return false;
  }
}


// Dijkstra's Algorithm
export function dijkstra(
  nodes: Node[],
  edges: Edge[],
  isDirected: boolean,
  startNodeId: string,
  endNodeId: string
): AlgorithmStep[] {
  stepCounterGlobal = 0; 
  const steps: AlgorithmStep[] = [];
  const nodeMap = new Map(nodes.map(n => [n.id, n]));
  const adj: Map<string, { target: string; weight: number; edgeId: string }[]> = new Map();

  nodes.forEach(node => adj.set(node.id, []));
  edges.forEach(edge => {
    adj.get(edge.source)!.push({ target: edge.target, weight: edge.weight, edgeId: edge.id });
    if (!isDirected && edge.source !== edge.target) { 
      adj.get(edge.target)!.push({ target: edge.source, weight: edge.weight, edgeId: edge.id });
    }
  });

  const dist: Map<string, number> = new Map(nodes.map(node => [node.id, INFINITY]));
  const prev: Map<string, { nodeId: string | null; edgeId: string | null }> = new Map(
    nodes.map(node => [node.id, { nodeId: null, edgeId: null }])
  );
  const pq: { id: string; priority: number }[] = []; 

  dist.set(startNodeId, 0);
  pq.push({ id: startNodeId, priority: 0 });
  steps.push({ id: generateStepId(), type: 'message', message: `Fillimi i Dijkstra nga ${nodeMap.get(startNodeId)?.label} te ${nodeMap.get(endNodeId)?.label}.` });
  steps.push({ id: generateStepId(), type: 'visit-node', nodeId: startNodeId, color: 'hsl(var(--accent))' });


  while (pq.length > 0) {
    pq.sort((a, b) => a.priority - b.priority); 
    const { id: u, priority: uDist } = pq.shift()!;

    if (uDist > dist.get(u)!) continue;
    if (u !== startNodeId) { 
        steps.push({ id: generateStepId(), type: 'visit-node', nodeId: u });
    }
    
    if (u === endNodeId) break; 

    (adj.get(u) || []).forEach(({ target: v, weight, edgeId }) => {
      steps.push({ id: generateStepId(), type: 'traverse-edge', edgeId, nodeId: v, highlightSourceNodeId: u });
      if (dist.get(u)! + weight < dist.get(v)!) {
        dist.set(v, dist.get(u)! + weight);
        prev.set(v, { nodeId: u, edgeId });
        pq.push({ id: v, priority: dist.get(v)! });
        steps.push({ id: generateStepId(), type: 'message', message: `Përditësohet ${nodeMap.get(v)?.label}: distanca ${dist.get(v)}` });
      }
    });
  }

  const pathNodes: string[] = [];
  let curr = endNodeId;

  if (dist.get(curr) === INFINITY) {
     steps.push({ id: generateStepId(), type: 'message', message: `Nuk ka rrugë nga ${nodeMap.get(startNodeId)?.label} te ${nodeMap.get(endNodeId)?.label}.` });
  } else {
    let pathReconstructionGuard = 0;
    const maxPathLength = nodes.length > 0 ? nodes.length : 1; // Max simple path length

    while (curr) {
      pathNodes.unshift(curr);
       if (pathReconstructionGuard++ > maxPathLength) {
            steps.push({ id: generateStepId(), type: 'message', message: `Gabim: Cikël i mundshëm gjatë rindërtimit të rrugës për Dijkstra.` });
            return steps; 
        }
      const p = prev.get(curr);
      if (p?.nodeId) { 
        curr = p.nodeId;
      } else {
        break;
      }
    }
    if (pathNodes.length > 0 && pathNodes[0] === startNodeId && dist.get(endNodeId) !== INFINITY) { 
        steps.push({ id: generateStepId(), type: 'highlight-path', path: pathNodes });
        steps.push({ id: generateStepId(), type: 'message', message: `Rruga më e shkurtër: ${pathNodes.map(id => nodeMap.get(id)?.label).join(' → ')}. Pesha: ${dist.get(endNodeId)}` });
    } else if (startNodeId === endNodeId) { 
        steps.push({ id: generateStepId(), type: 'highlight-path', path: [startNodeId] });
        steps.push({ id: generateStepId(), type: 'message', message: `Rruga më e shkurtër: ${nodeMap.get(startNodeId)?.label}. Pesha: 0` });
    } else if (dist.get(endNodeId) !== INFINITY) { // Path found but might not start with startNodeId (e.g. if graph is disconnected but endNodeId is reachable from somewhere)
        steps.push({ id: generateStepId(), type: 'message', message: `Rrugë e gjetur, por nuk fillon nga nyja fillestare e specifikuar. Detaje: ${pathNodes.map(id => nodeMap.get(id)?.label).join(' → ')}. Pesha: ${dist.get(endNodeId)}` });
    }
  }
  return steps;
}

// Breadth-First Search (BFS)
export function bfs(
  nodes: Node[],
  edges: Edge[],
  isDirected: boolean,
  startNodeId: string
): AlgorithmStep[] {
  stepCounterGlobal = 0;
  const steps: AlgorithmStep[] = [];
  const nodeMap = new Map(nodes.map(n => [n.id, n]));
  const adj: Map<string, { target: string; edgeId: string }[]> = new Map();

  nodes.forEach(node => adj.set(node.id, []));
  edges.forEach(edge => {
    adj.get(edge.source)!.push({ target: edge.target, edgeId: edge.id });
    if (!isDirected && edge.source !== edge.target) {
      adj.get(edge.target)!.push({ target: edge.source, edgeId: edge.id });
    }
  });

  const visited: Set<string> = new Set();
  const queue: string[] = [];
  
  steps.push({ id: generateStepId(), type: 'message', message: `Fillimi i BFS nga ${nodeMap.get(startNodeId)?.label}.` });
  
  visited.add(startNodeId);
  queue.push(startNodeId);
  steps.push({ id: generateStepId(), type: 'visit-node', nodeId: startNodeId, color: 'hsl(var(--accent))' });

  let head = 0;
  while(head < queue.length) {
    const u = queue[head++];
    
    (adj.get(u) || []).forEach(({ target: v, edgeId }) => {
      if (!visited.has(v)) {
        visited.add(v);
        queue.push(v);
        steps.push({ id: generateStepId(), type: 'traverse-edge', edgeId, nodeId: v, highlightSourceNodeId: u });
        steps.push({ id: generateStepId(), type: 'visit-node', nodeId: v });
      }
    });
  }
  steps.push({ id: generateStepId(), type: 'message', message: `BFS përfundoi. Nyjet e vizituara (rendi i zbulimit): ${queue.map(id => nodeMap.get(id)?.label).join(', ')}` });
  if (queue.length > 0) { 
    steps.push({ id: generateStepId(), type: 'highlight-path', path: queue, color: 'hsl(var(--primary))' }); 
  }
  return steps;
}

// Depth-First Search (DFS)
export function dfs(
  nodes: Node[],
  edges: Edge[],
  isDirected: boolean,
  startNodeId: string
): AlgorithmStep[] {
  stepCounterGlobal = 0;
  const steps: AlgorithmStep[] = [];
  const nodeMap = new Map(nodes.map(n => [n.id, n]));
  const adj: Map<string, { target: string; edgeId: string }[]> = new Map();

  nodes.forEach(node => adj.set(node.id, []));
  edges.forEach(edge => {
    adj.get(edge.source)!.push({ target: edge.target, edgeId: edge.id });
    if (!isDirected && edge.source !== edge.target) {
      adj.get(edge.target)!.push({ target: edge.source, edgeId: edge.id });
    }
  });

  const visited: Set<string> = new Set();
  const pathForHighlight: string[] = []; 

  function dfsVisit(u: string) {
    visited.add(u);
    pathForHighlight.push(u);
    steps.push({ id: generateStepId(), type: 'visit-node', nodeId: u, color: 'hsl(var(--accent))' });

    (adj.get(u) || []).forEach(({ target: v, edgeId }) => {
      if (!visited.has(v)) {
        steps.push({ id: generateStepId(), type: 'traverse-edge', edgeId, nodeId: v, highlightSourceNodeId: u });
        dfsVisit(v);
      }
    });
  }
  
  steps.push({ id: generateStepId(), type: 'message', message: `Fillimi i DFS nga ${nodeMap.get(startNodeId)?.label}.` });
  dfsVisit(startNodeId);
  
  steps.push({ id: generateStepId(), type: 'message', message: `DFS përfundoi. Nyjet e vizituara (rendi i parë i vizitës): ${pathForHighlight.map(id => nodeMap.get(id)?.label).join(' → ')}` });

  if(pathForHighlight.length > 0){
      steps.push({ id: generateStepId(), type: 'highlight-path', path: pathForHighlight, color: 'hsl(var(--primary))' });
  }
  return steps;
}


// A* Algorithm
export function aStar(
  nodes: Node[],
  edges: Edge[],
  isDirected: boolean,
  startNodeId: string,
  endNodeId: string
): AlgorithmStep[] {
  stepCounterGlobal = 0;
  const steps: AlgorithmStep[] = [];
  const nodeMap = new Map(nodes.map(n => [n.id, n]));

  const adj: Map<string, { target: string; weight: number; edgeId: string }[]> = new Map();
  nodes.forEach(node => adj.set(node.id, []));
  edges.forEach(edge => {
    adj.get(edge.source)!.push({ target: edge.target, weight: edge.weight, edgeId: edge.id });
    if (!isDirected && edge.source !== edge.target) {
      adj.get(edge.target)!.push({ target: edge.source, weight: edge.weight, edgeId: edge.id });
    }
  });

  const openSet: { id: string; fScore: number }[] = []; // Array acting as PQ
  const closedSet: Set<string> = new Set(); // Set to keep track of processed nodes
  const cameFrom: Map<string, { nodeId: string | null; edgeId: string | null }> = new Map();

  const gScore: Map<string, number> = new Map(nodes.map(node => [node.id, INFINITY]));
  gScore.set(startNodeId, 0);

  const fScore: Map<string, number> = new Map(nodes.map(node => [node.id, INFINITY]));
  const startNodeObj = nodeMap.get(startNodeId);
  const endNodeObj = nodeMap.get(endNodeId);

  if (!startNodeObj || !endNodeObj) {
    steps.push({ id: generateStepId(), type: 'message', message: "Nyja fillestare ose përfundimtare nuk u gjet." });
    return steps;
  }

  fScore.set(startNodeId, heuristic(startNodeObj, endNodeObj));
  openSet.push({ id: startNodeId, fScore: fScore.get(startNodeId)! });

  steps.push({ id: generateStepId(), type: 'message', message: `Fillimi i A* nga ${startNodeObj.label} te ${endNodeObj.label}.` });
  steps.push({ id: generateStepId(), type: 'visit-node', nodeId: startNodeId, color: 'hsl(var(--accent))' });

  while (openSet.length > 0) {
    openSet.sort((a, b) => a.fScore - b.fScore); 
    const { id: currentId } = openSet.shift()!; 

    if (closedSet.has(currentId)) { 
        continue;
    }
    closedSet.add(currentId); 

    const currentNode = nodeMap.get(currentId)!; // Should exist if in openSet

    if (currentId === endNodeId) { 
      const pathNodes: string[] = [];
      let curr: string | null = endNodeId;
      let pathReconstructionGuard = 0;
      // Max simple path length in a graph with V nodes is V.
      // If path reconstruction exceeds this, it implies a cycle in `cameFrom` or other issue.
      const maxPathLength = nodes.length > 0 ? nodes.length : 1; 

      while (curr) {
        pathNodes.unshift(curr);
        if (pathReconstructionGuard++ > maxPathLength) { 
            steps.push({ id: generateStepId(), type: 'message', message: `Gabim kritik: Cikël i pafund gjatë rindërtimit të rrugës A*. Ndërpritet.` });
            return steps; 
        }
        const prev = cameFrom.get(curr);
        curr = prev ? prev.nodeId : null;
      }
      if (pathNodes[0] !== startNodeId && startNodeId !== endNodeId) {
         steps.push({ id: generateStepId(), type: 'message', message: `Gabim: Rruga A* e rindërtuar nuk fillon nga nyja fillestare.` });
      } else {
        steps.push({ id: generateStepId(), type: 'highlight-path', path: pathNodes });
        steps.push({ id: generateStepId(), type: 'message', message: `Rruga më e mirë (A*): ${pathNodes.map(id => nodeMap.get(id)?.label).join(' → ')}. Kostoja: ${gScore.get(endNodeId)}` });
      }
      return steps;
    }

    if (currentId !== startNodeId) { 
         steps.push({ id: generateStepId(), type: 'visit-node', nodeId: currentId });
    }

    (adj.get(currentId) || []).forEach(({ target: neighborId, weight, edgeId }) => {
      if (closedSet.has(neighborId)) { 
        return; 
      }

      const neighborNode = nodeMap.get(neighborId)!; // Should exist
      const tentativeGScore = gScore.get(currentId)! + weight;

      steps.push({ id: generateStepId(), type: 'traverse-edge', edgeId, nodeId: neighborId, highlightSourceNodeId: currentId });

      if (tentativeGScore < (gScore.get(neighborId) || INFINITY)) {
        cameFrom.set(neighborId, { nodeId: currentId, edgeId });
        gScore.set(neighborId, tentativeGScore);
        const newFScore = tentativeGScore + heuristic(neighborNode, endNodeObj);
        fScore.set(neighborId, newFScore);
        
        const openSetIndex = openSet.findIndex(item => item.id === neighborId);
        if (openSetIndex > -1) {
          openSet[openSetIndex].fScore = newFScore; 
        } else {
          openSet.push({ id: neighborId, fScore: newFScore }); 
        }
        steps.push({ id: generateStepId(), type: 'message', message: `Përditësohet ${neighborNode.label}: gScore ${gScore.get(neighborId)}, fScore ${fScore.get(neighborId)}` });
      }
    });
  }

  steps.push({ id: generateStepId(), type: 'message', message: `Nuk ka rrugë nga ${startNodeObj.label} te ${endNodeObj.label} duke përdorur A*.` });
  return steps;
}

// Bellman-Ford Algorithm
export function bellmanFord(
  nodes: Node[],
  edges: Edge[],
  isDirected: boolean, 
  startNodeId: string
): AlgorithmStep[] {
  stepCounterGlobal = 0;
  const steps: AlgorithmStep[] = [];
  const nodeMap = new Map(nodes.map(n => [n.id, n]));

  const dist: Map<string, number> = new Map(nodes.map(node => [node.id, INFINITY]));
  const prev: Map<string, { nodeId: string | null; edgeId: string | null }> = new Map();
  dist.set(startNodeId, 0);

  steps.push({ id: generateStepId(), type: 'message', message: `Fillimi i Bellman-Ford nga ${nodeMap.get(startNodeId)?.label}.` });
  steps.push({ id: generateStepId(), type: 'visit-node', nodeId: startNodeId, color: 'hsl(var(--accent))' });

  const allEdgesForBellmanFord = [];
  edges.forEach(edge => {
    allEdgesForBellmanFord.push({ source: edge.source, target: edge.target, weight: edge.weight, id: edge.id });
    if (!isDirected && edge.source !== edge.target) { 
        allEdgesForBellmanFord.push({ source: edge.target, target: edge.source, weight: edge.weight, id: `${edge.id}-rev` }); // Consider reverse for undirected
    }
  });


  for (let i = 0; i < nodes.length - 1; i++) {
    steps.push({ id: generateStepId(), type: 'message', message: `Iteracioni ${i + 1}/${nodes.length -1 }`});
    let changedInIteration = false;
    for (const edge of allEdgesForBellmanFord) {
      if (dist.get(edge.source)! !== INFINITY && dist.get(edge.source)! + edge.weight < dist.get(edge.target)!) {
        dist.set(edge.target, dist.get(edge.source)! + edge.weight);
        prev.set(edge.target, { nodeId: edge.source, edgeId: edge.id }); // Store original edge ID
        steps.push({ id: generateStepId(), type: 'traverse-edge', edgeId: edge.id, nodeId: edge.target, highlightSourceNodeId: edge.source });
        steps.push({ id: generateStepId(), type: 'message', message: `Relaksimi ${nodeMap.get(edge.source)?.label}-${nodeMap.get(edge.target)?.label}. Distanca e re te ${nodeMap.get(edge.target)?.label}: ${dist.get(edge.target)}` });
        changedInIteration = true;
      }
    }
    if (!changedInIteration && i < nodes.length -2) { // Optimization: if no changes in an iteration (except the last one for cycle check)
        steps.push({ id: generateStepId(), type: 'message', message: `Nuk ka ndryshime në iteracionin ${i+1}, ndërpritet herët.`});
        break; 
    }
  }

  let negativeCycleDetected = false;
  for (const edge of allEdgesForBellmanFord) {
    if (dist.get(edge.source)! !== INFINITY && dist.get(edge.source)! + edge.weight < dist.get(edge.target)!) {
      steps.push({ id: generateStepId(), type: 'message', message: `Cikël me peshë negative u detektua afër brinjës ${nodeMap.get(edge.source)?.label}-${nodeMap.get(edge.target)?.label}!` });
      negativeCycleDetected = true;
      steps.push({ id: generateStepId(), type: 'traverse-edge', edgeId: edge.id, nodeId: edge.target, highlightSourceNodeId: edge.source, color: 'hsl(var(--destructive))' });
      // Optionally, can try to trace and highlight the cycle itself, but this is complex.
      // To avoid further complex path display if a cycle is found:
      dist.set(edge.target, -INFINITY); // Mark nodes reachable by negative cycles
      // break; // Can break after first detection or continue to find all problematic edges.
    }
  }

  if (!negativeCycleDetected) {
    steps.push({ id: generateStepId(), type: 'message', message: "Bellman-Ford përfundoi. Nuk u detektuan cikle me peshë negative." });
    nodes.forEach(node => {
        if (node.id !== startNodeId && dist.get(node.id) !== INFINITY) {
            const pathNodes: string[] = [];
            let curr: string | null = node.id;
            let pathReconstructionGuard = 0;
            const maxPathLength = nodes.length > 0 ? nodes.length : 1;
            while(curr) {
                pathNodes.unshift(curr);
                if (pathReconstructionGuard++ > maxPathLength) {
                     pathNodes.unshift("... (cikël?)"); 
                     break;
                }
                const p = prev.get(curr);
                curr = p ? p.nodeId : null;
            }
            if (pathNodes[0] === startNodeId || (pathNodes.length > 1 && pathNodes[1] === startNodeId)) { 
                 steps.push({ id: generateStepId(), type: 'highlight-path', path: pathNodes.filter(p => p !== "... (cikël?)"), color: 'hsl(var(--primary))' });
                 steps.push({ id: generateStepId(), type: 'message', message: `Rruga më e shkurtër te ${nodeMap.get(node.id)?.label}: ${pathNodes.map(id => nodeMap.get(id)?.label || id).join(' → ')}. Pesha: ${dist.get(node.id)}` });
            } else if (dist.get(node.id) !== INFINITY) {
                 steps.push({ id: generateStepId(), type: 'message', message: `Distanca te ${nodeMap.get(node.id)?.label}: ${dist.get(node.id)}. Rruga nuk mund të rindërtohet qartë nga fillimi.` });
            }
        } else if (node.id === startNodeId) {
            steps.push({ id: generateStepId(), type: 'message', message: `Distanca te ${nodeMap.get(startNodeId)?.label}: 0`});
        } else if (dist.get(node.id) === INFINITY) {
             steps.push({ id: generateStepId(), type: 'message', message: `Nuk ka rrugë te ${nodeMap.get(node.id)?.label}`});
        }
    });

  } else {
     steps.push({ id: generateStepId(), type: 'message', message: "Bellman-Ford përfundoi. KUJDES: Cikël(e) me peshë negative u detektua(n)!" });
  }
  return steps;
}


// Floyd-Warshall Algorithm
export function floydWarshall(
  nodes: Node[],
  edges: Edge[],
  isDirected: boolean
): AlgorithmStep[] {
  stepCounterGlobal = 0;
  const steps: AlgorithmStep[] = [];
  const nodeMap = new Map(nodes.map(n => [n.id, n]));
  const nodeIndexMap = new Map(nodes.map((node, i) => [node.id, i]));
  const numNodes = nodes.length;

  if (numNodes === 0) {
    steps.push({ id: generateStepId(), type: 'message', message: "Grafi është bosh, Floyd-Warshall nuk mund të ekzekutohet." });
    return steps;
  }

  const dist: number[][] = Array(numNodes).fill(null).map(() => Array(numNodes).fill(INFINITY));
  const next: (number | null)[][] = Array(numNodes).fill(null).map(() => Array(numNodes).fill(null)); // Për ruajtjen e rrugëve

  for (let i = 0; i < numNodes; i++) {
    dist[i][i] = 0;
  }

  edges.forEach(edge => {
    const u = nodeIndexMap.get(edge.source)!;
    const v = nodeIndexMap.get(edge.target)!;
    if (u === undefined || v === undefined) return;

    if (edge.weight < dist[u][v]) {
      dist[u][v] = edge.weight;
      next[u][v] = v; // Ruaj nyjen e radhës për rrugën
    }
    if (!isDirected && u !== v) {
      if (edge.weight < dist[v][u]) {
        dist[v][u] = edge.weight;
        next[v][u] = u; // Ruaj nyjen e radhës për rrugën
      }
    }
  });
  
  steps.push({ id: generateStepId(), type: 'message', message: `Fillimi i Floyd-Warshall.` });

  for (let k_idx = 0; k_idx < numNodes; k_idx++) {
    const k_node = nodes[k_idx];
    steps.push({ id: generateStepId(), type: 'visit-node', nodeId: k_node.id, message: `Konsiderohet nyja e ndërmjetme: ${k_node.label} (indeksi ${k_idx})`, color: 'hsl(var(--secondary-foreground))' });
    for (let i_idx = 0; i_idx < numNodes; i_idx++) {
      for (let j_idx = 0; j_idx < numNodes; j_idx++) {
        if (dist[i_idx][k_idx] !== INFINITY && dist[k_idx][j_idx] !== INFINITY && 
            dist[i_idx][k_idx] + dist[k_idx][j_idx] < dist[i_idx][j_idx]) {
          
          const oldDist = dist[i_idx][j_idx];
          dist[i_idx][j_idx] = dist[i_idx][k_idx] + dist[k_idx][j_idx];
          next[i_idx][j_idx] = next[i_idx][k_idx]; // Përditëso nyjen e radhës për rrugën
          
          const i_node_label = nodes[i_idx].label;
          const j_node_label = nodes[j_idx].label;
          
          steps.push({ 
            id: generateStepId(), 
            type: 'update-matrix-cell', 
            message: `Përditësohet dist(${i_node_label}, ${j_node_label}) nga ${oldDist === INFINITY ? '∞' : oldDist} në ${dist[i_idx][j_idx]} përmes ${k_node.label}.`,
            matrixCell: { row: i_idx, col: j_idx, value: dist[i_idx][j_idx] }
          });
        }
      }
    }
  }
  
  // Kontrollo për cikle negative
  for (let i = 0; i < numNodes; i++) {
    if (dist[i][i] < 0) {
      steps.push({ id: generateStepId(), type: 'message', message: `Cikël me peshë negative u detektua që përfshin nyjën ${nodes[i].label}.` });
    }
  }

  steps.push({ id: generateStepId(), type: 'message', message: `Floyd-Warshall përfundoi. Shfaqen distancat dhe rrugët për të gjitha çiftet e nyjeve:` });

  // Funksion ndihmës për të gjetur rrugën nga i te j
  function getPath(i: number, j: number): string[] {
    if (next[i][j] === null) return [];
    const path: string[] = [nodes[i].id]; // Ndryshuar nga label në id për highlight-path
    let current = i;
    while (current !== j) {
      current = next[current][j]!;
      path.push(nodes[current].id); // Ndryshuar nga label në id për highlight-path
    }
    return path;
  }

  // Grup rrugët sipas nyjes fillestare për organizim më të mirë
  const pathsByStartNode = new Map<string, { target: string; path: string[]; distance: number }[]>();
  
  // Mblidh të gjitha rrugët
  for (let i = 0; i < numNodes; i++) {
    const startNode = nodes[i];
    const paths: { target: string; path: string[]; distance: number }[] = [];
    
    for (let j = 0; j < numNodes; j++) {
      if (i !== j && dist[i][j] !== INFINITY) {
        const path = getPath(i, j);
        if (path.length > 0) {
          paths.push({
            target: nodes[j].id,
            path,
            distance: dist[i][j]
          });
        }
      }
    }
    
    if (paths.length > 0) {
      pathsByStartNode.set(startNode.id, paths);
    }
  }

  // Shfaq rrugët e grupuara sipas nyjes fillestare
  pathsByStartNode.forEach((paths, startNodeId) => {
    const startNode = nodeMap.get(startNodeId)!;
    steps.push({ 
      id: generateStepId(), 
      type: 'message', 
      message: `\nRrugët nga ${startNode.label}:`
    });

    paths.forEach(({ target, path, distance }) => {
      const targetNode = nodeMap.get(target)!;
      steps.push({ 
        id: generateStepId(), 
        type: 'highlight-path', 
        path,
        color: 'hsl(var(--primary))'
      });
      steps.push({ 
        id: generateStepId(), 
        type: 'message', 
        message: `→ ${targetNode.label}: ${path.map(id => nodeMap.get(id)?.label).join(' → ')} (distanca: ${distance})`
      });
    });
  });

  // Shfaq matricën e distancave në fund
  steps.push({ 
    id: generateStepId(), 
    type: 'message', 
    message: '\nMatrica e distancave:'
  });
  
  // Header row
  const headerRow = ['', ...nodes.map(n => n.label)];
  steps.push({ 
    id: generateStepId(), 
    type: 'message', 
    message: headerRow.join('\t')
  });

  // Data rows
  nodes.forEach((node, i) => {
    const row = [node.label, ...nodes.map((_, j) => dist[i][j] === INFINITY ? "∞" : dist[i][j])];
    steps.push({ 
      id: generateStepId(), 
      type: 'message', 
      message: row.join('\t')
    });
  });

  return steps;
}


// Kruskal's Algorithm (MST)
export function kruskal(
  nodes: Node[],
  edges: Edge[]
): AlgorithmStep[] {
  stepCounterGlobal = 0;
  const steps: AlgorithmStep[] = [];
  if (nodes.length === 0) {
    steps.push({id: generateStepId(), type: 'message', message: "Grafi është bosh."});
    return steps;
  }
  
  const nodeMap = new Map(nodes.map(n => [n.id, n]));
  const sortedEdges = [...edges].sort((a, b) => a.weight - b.weight);
  const dsu = new DSU(nodes);
  const mstEdges: Edge[] = []; 
  let mstWeight = 0;

  steps.push({ id: generateStepId(), type: 'message', message: `Fillimi i Algoritmit të Kruskal-it.` });

  for (const edge of sortedEdges) {
    steps.push({ id: generateStepId(), type: 'traverse-edge', edgeId: edge.id, nodeId: edge.target, highlightSourceNodeId: edge.source, color: "hsl(var(--muted-foreground))" });
    if (dsu.union(edge.source, edge.target)) {
      mstEdges.push(edge);
      mstWeight += edge.weight;
      steps.push({ id: generateStepId(), type: 'message', message: `Shtohet brinja ${nodeMap.get(edge.source)?.label}-${nodeMap.get(edge.target)?.label} (pesha: ${edge.weight}) në MST.` });
      steps.push({ id: generateStepId(), type: 'traverse-edge', edgeId: edge.id, nodeId: edge.target, highlightSourceNodeId: edge.source, color: 'hsl(var(--accent))' }); 
      if (mstEdges.length === nodes.length - 1 && nodes.length > 0) break; 
    } else {
       steps.push({ id: generateStepId(), type: 'message', message: `Brinja ${nodeMap.get(edge.source)?.label}-${nodeMap.get(edge.target)?.label} formon cikël, injorohet.` });
    }
  }

  if (mstEdges.length < nodes.length - 1 && nodes.length > 1 && nodes.some(n => dsu.find(n.id) !== dsu.find(nodes[0].id))) { // Check if graph is connected
     steps.push({ id: generateStepId(), type: 'message', message: "Grafi nuk është i lidhur, nuk mund të formohet një MST e plotë." });
  }
  
  const mstNodeIdsForPathHighlight: string[] = [];
  if (mstEdges.length > 0) {
      // Create a path for highlight from the MST edges (e.g., by DFS/BFS on MST)
      const mstAdj = new Map<string, string[]>();
      const visitedForPath = new Set<string>();
      mstEdges.forEach(e => {
          if (!mstAdj.has(e.source)) mstAdj.set(e.source, []);
          if (!mstAdj.has(e.target)) mstAdj.set(e.target, []);
          mstAdj.get(e.source)!.push(e.target);
          mstAdj.get(e.target)!.push(e.source);
      });

      function buildMstPath(u: string) {
          visitedForPath.add(u);
          mstNodeIdsForPathHighlight.push(u);
          (mstAdj.get(u) || []).forEach(v => {
              if (!visitedForPath.has(v)) buildMstPath(v);
          });
      }
      // Start DFS/BFS for path from the first node involved in MST or just nodes[0] if part of MST
      let startNodeForMstTraversal = nodes[0]?.id;
      if (mstEdges.length > 0) {
          const firstEdgeSource = mstEdges[0].source;
          if(nodes.find(n=>n.id === firstEdgeSource)) startNodeForMstTraversal = firstEdgeSource;
      }

      if (startNodeForMstTraversal && mstAdj.has(startNodeForMstTraversal)) {
         buildMstPath(startNodeForMstTraversal);
      } else if (nodes.length > 0 && mstEdges.length < nodes.length -1) {
          // Try to find any node that is part of an MST component if graph not fully connected
          for(const node of nodes){
              if(mstAdj.has(node.id) && !visitedForPath.has(node.id)){
                  buildMstPath(node.id);
              }
          }
      }
      
      if (mstNodeIdsForPathHighlight.length > 0) {
         steps.push({ id: generateStepId(), type: 'highlight-path', path: mstNodeIdsForPathHighlight, color: 'hsl(var(--primary))' });
      }
  }


  steps.push({ id: generateStepId(), type: 'message', message: `Algoritmi i Kruskal-it përfundoi. Pesha totale e MST: ${mstWeight}.` });
  return steps;
}


// Prim's Algorithm (MST)
export function prim(
  nodes: Node[],
  edges: Edge[],
  isDirected: boolean, 
  startNodeId: string
): AlgorithmStep[] {
  stepCounterGlobal = 0;
  const steps: AlgorithmStep[] = [];
   if (nodes.length === 0) {
    steps.push({id: generateStepId(), type: 'message', message: "Grafi është bosh."});
    return steps;
  }

  const nodeMap = new Map(nodes.map(n => [n.id, n]));
  const adj: Map<string, { target: string; weight: number; edgeId: string }[]> = new Map();
  nodes.forEach(node => adj.set(node.id, []));
  edges.forEach(edge => {
    adj.get(edge.source)!.push({ target: edge.target, weight: edge.weight, edgeId: edge.id });
    if (!isDirected && edge.source !== edge.target) { 
       adj.get(edge.target)!.push({ target: edge.source, weight: edge.weight, edgeId: edge.id }); 
    }
  });

  const key: Map<string, number> = new Map(nodes.map(node => [node.id, INFINITY]));
  const parent: Map<string, { nodeId: string | null; edgeId: string | null }> = new Map();
  const inMST: Set<string> = new Set();
  const pq: { id: string; keyVal: number }[] = []; 

  key.set(startNodeId, 0);
  // Initialize PQ only with the start node or all nodes depending on Prim's variant.
  // For "eager" Prim, PQ contains nodes not yet in MST.
  pq.push({id: startNodeId, keyVal: 0});
  // Or initialize with all nodes if preferred:
  // nodes.forEach(node => pq.push({ id: node.id, keyVal: key.get(node.id)! }));
  
  steps.push({ id: generateStepId(), type: 'message', message: `Fillimi i Algoritmit të Prim-it nga ${nodeMap.get(startNodeId)?.label}.` });

  const mstPathForHighlight: string[] = [];
  let mstWeight = 0;

  while (pq.length > 0) {
    pq.sort((a, b) => a.keyVal - b.keyVal); 
    const { id: u_id, keyVal: u_key } = pq.shift()!;

    if (inMST.has(u_id)) continue; 
    
    inMST.add(u_id);
    mstPathForHighlight.push(u_id);
    
    // u_key is the weight of the edge connecting u_id to the MST.
    // For the start node, u_key is 0 (or its initial key if not starting from 0).
    // Only add edge weight if it's not the start node or if key wasn't 0 initially.
    if (parent.has(u_id)) { // i.e. if u_id is not the startNode (whose parent is not set) or if its key was updated from INFINITY
         mstWeight += u_key;
    }


    steps.push({ id: generateStepId(), type: 'visit-node', nodeId: u_id, color: 'hsl(var(--accent))'});
    const pEdgeInfo = parent.get(u_id);
    if (pEdgeInfo?.nodeId && pEdgeInfo?.edgeId) { 
      steps.push({ id: generateStepId(), type: 'traverse-edge', edgeId: pEdgeInfo.edgeId, nodeId: u_id, highlightSourceNodeId: pEdgeInfo.nodeId, color: 'hsl(var(--primary))'});
      steps.push({ id: generateStepId(), type: 'message', message: `Shtohet brinja ${nodeMap.get(pEdgeInfo.nodeId)?.label}-${nodeMap.get(u_id)?.label} (pesha ${u_key}) në MST.`})
    }


    (adj.get(u_id) || []).forEach(({ target: v_id, weight, edgeId }) => {
      if (!inMST.has(v_id) && weight < key.get(v_id)!) {
        key.set(v_id, weight);
        parent.set(v_id, { nodeId: u_id, edgeId });
        
        const pqEntryIndex = pq.findIndex(item => item.id === v_id);
        if (pqEntryIndex > -1) {
            pq[pqEntryIndex].keyVal = weight;
        } else {
            pq.push({id: v_id, keyVal: weight});
        }

        steps.push({ id: generateStepId(), type: 'traverse-edge', edgeId: edgeId, nodeId: v_id, highlightSourceNodeId: u_id, color: "hsl(var(--muted-foreground))" }); 
        steps.push({ id: generateStepId(), type: 'message', message: `Përditësohet kandidati për MST: nyja ${nodeMap.get(v_id)?.label}, pesha e brinjës ${weight} nga ${nodeMap.get(u_id)?.label}.` });
      }
    });
    if (inMST.size === nodes.length) break; // Optimization: if all nodes are in MST
  }
  
  if (mstPathForHighlight.length < nodes.length && nodes.length > 0) {
      steps.push({ id: generateStepId(), type: 'message', message: "Grafi nuk është i lidhur, nuk mund të formohet një MST e plotë për të gjitha nyjet." });
  }
  if (mstPathForHighlight.length > 0) {
    steps.push({ id: generateStepId(), type: 'highlight-path', path: mstPathForHighlight, color: 'hsl(var(--primary))' });
  }

  steps.push({ id: generateStepId(), type: 'message', message: `Algoritmi i Prim-it përfundoi. Pesha totale e MST: ${mstWeight}.` });
  return steps;
}

    