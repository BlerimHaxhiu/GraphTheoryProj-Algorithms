# **App Name**: GrafiShqip

## Core Features:

- Graph Construction: Enable users to visually construct graphs by adding nodes and edges, specifying weights, and toggling directed or undirected graphs.
- Graph Drag and Drop: Allow users to move the graph by dragging and dropping
- Graph Algorithms: Implement Dijkstra, BFS, and DFS algorithms to operate on the created graphs.
- Algorithm Recommendation: Utilize a generative AI tool to analyze algorithm performance (Dijkstra, BFS, DFS) on the current graph, and suggest the best one based on runtime and total weight of edges. Provide insights in albanian.
- Adjacency Matrix Display: Display the graph's adjacency matrix and highlight the matrix update in real-time as algorithms progress.

## Style Guidelines:

- Primary color: Light gray (#F5F5F5) for a clean background.
- Secondary color: Dark gray (#333) for contrast and text.
- Accent: Green (#4CAF50) to indicate nodes, edges and path highlights.
- Use a clear, sans-serif font to ensure readability.
- Simple, clear icons for node and edge creation/manipulation.
- Use a clear, structured layout to keep the different graph representations apart